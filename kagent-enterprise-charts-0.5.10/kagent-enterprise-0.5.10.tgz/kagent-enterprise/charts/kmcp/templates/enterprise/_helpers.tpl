{{/*
Renders the enterprise licensing checksum annotation.
Outputs solo.io/licensing-checksum only when createSecret is true (global or local).
*/}}
{{- define "kmcp-enterprise.licensingAnnotation" -}}
{{- $globalLicensing := ((.Values.global).licensing) | default dict -}}
{{- $localLicensing := .Values.licensing | default dict -}}
{{- $createSecret := $globalLicensing.createSecret -}}
{{- if kindIs "bool" $localLicensing.createSecret -}}
{{- $createSecret = $localLicensing.createSecret -}}
{{- end -}}
{{- if $createSecret }}
solo.io/licensing-checksum: {{ list (toYaml $localLicensing) (toYaml $globalLicensing) | join "" | sha256sum }}
{{- end -}}
{{- end -}}

{{/*
Renders enterprise-specific env vars for the kmcp controller deployment.
Includes ENABLE_ISTIO_AUTHZ_TRANSLATION and license key configuration.
Fails at render time if neither secretName nor licenseFilePath is configured.
*/}}
{{- define "kmcp-enterprise.controllerEnv" -}}
{{- $globalLicensing := ((.Values.global).licensing) | default dict -}}
{{- $localLicensing := .Values.licensing | default dict -}}
{{- $secretName := coalesce $localLicensing.secretName $globalLicensing.secretName -}}
{{- $licenseFilePath := coalesce $localLicensing.licenseFilePath $globalLicensing.licenseFilePath -}}
- name: ENABLE_ISTIO_AUTHZ_TRANSLATION
  value: {{ .Values.controller.istioAuthzTranslation.enabled | default false | quote }}
{{- /* Identify the kagent controller so the MCPServer waypoint AuthorizationPolicy can allow it
       (the controller proxies the UI's tool calls). Namespace comes from the pod (kmcp runs in the
       install namespace alongside the controller); the SA name is supplied by the parent chart. */}}
- name: KAGENT_CONTROLLER_NAMESPACE
  valueFrom:
    fieldRef:
      fieldPath: metadata.namespace
{{- with .Values.controller.kagentControllerServiceAccount }}
- name: KAGENT_CONTROLLER_SA
  value: {{ . | quote }}
{{- end }}
{{- if and (not $secretName) (not $licenseFilePath) -}}
{{- fail "licensing misconfigured: set licensing.secretName or global.licensing.secretName (Kubernetes Secret), or licensing.licenseFilePath or global.licensing.licenseFilePath (file path for a volume-mounted key)" -}}
{{- end -}}
{{- if $licenseFilePath }}
- name: ENTERPRISE_KAGENT_LICENSE_KEY_PATH
  value: {{ $licenseFilePath | quote }}
{{- else }}
- name: ENTERPRISE_KAGENT_LICENSE_KEY
  valueFrom:
    secretKeyRef:
      name: {{ $secretName }}
      key: enterprise-kagent-license-key
      optional: true
{{- end -}}
{{- end -}}
