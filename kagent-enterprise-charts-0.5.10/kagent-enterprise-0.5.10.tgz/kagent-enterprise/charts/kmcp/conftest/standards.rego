package main

import rego.v1
import data.helm_standards

exempt := {}

deny contains v.msg if {
	v := helm_standards.violations[_]
	not exempt[{"rule": v.rule, "resource": v.resource}]
}
