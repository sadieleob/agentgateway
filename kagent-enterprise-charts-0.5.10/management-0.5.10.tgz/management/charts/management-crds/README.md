
<img src="https://img.shields.io/badge/Version-0.0.0-informational?style=flat-square" alt="Version: 0.0.0" align="left">

<br>Review Helm values for the `management-crds` Helm chart, which installs Custom Resource Definitions (CRDs) for the Solo platform.

## Overview

The management-crds chart deploys the CRDs required for the Solo platform.

For more information, see the [installation guide](https://docs.solo.io/kagent/latest/install/install-kagent/).

## Installation order

This chart **must** be installed before the `management` chart. CRDs must exist in the cluster before any of the platform compnents are deployed.

## Upgrading CRDs

Helm does not upgrade or delete CRDs during chart upgrades. To update CRDs to a newer version, you must manually apply the updated CRD definitions or use `helm upgrade` with the `--force` flag (which will recreate resources). For more information, see the [Helm documentation on CRDs](https://helm.sh/docs/chart_best_practices/custom_resource_definitions/).
