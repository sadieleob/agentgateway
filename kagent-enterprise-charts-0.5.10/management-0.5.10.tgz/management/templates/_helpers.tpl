{{/*
Build a full image reference for a solo-owned image.
Usage: {{ include "solo-enterprise.image" (dict "global" .Values.global "image" .Values.tunnelserver "chartVersion" .Chart.Version) }}
global.image.registry and global.image.repository override per-image values when set.
*/}}
{{- define "solo-enterprise.image" -}}
{{- $registry := coalesce .image.registry .global.image.registry }}
{{- $repository := coalesce .image.repository .global.image.repository }}
{{- $tag := coalesce .image.tag .global.image.tag .chartVersion }}
{{- printf "%s/%s/%s:%s" $registry $repository .image.name $tag }}
{{- end }}

{{- define "ui-frontend.image-tag" -}}
{{- coalesce .Values.ui.frontend.tag .Chart.Version }}
{{- end }}

{{- define "idp.image" -}}
{{- $registry := .Values.idp.registry }}
{{- $repository := .Values.idp.repository }}
{{- $name := .Values.idp.name }}
{{- $tag := coalesce .Values.idp.tag .Chart.Version }}
{{- printf "%s/%s/%s:%s" $registry $repository $name $tag }}
{{- end }}

{{/*
Render imagePullSecrets from .Values.imagePullSecrets (deprecated) and .Values.global.imagePullSecrets.
Both lists are merged; .Values.imagePullSecrets is kept for backwards compatibility.
Usage: {{- include "management.imagePullSecrets" . | nindent 6 }}
*/}}
{{- define "management.imagePullSecrets" -}}
{{- $legacy := .Values.imagePullSecrets | default list -}}
{{- $global := ((.Values.global).imagePullSecrets) | default list -}}
{{- $merged := concat $legacy $global -}}
{{- if $merged -}}
imagePullSecrets:
{{- toYaml $merged | nindent 2 }}
{{- end -}}
{{- end -}}

{{/*
Emit a deprecation warning if the legacy .Values.imagePullSecrets field is set.
*/}}
{{- define "management.imagePullSecretsWarning" -}}
{{- if .Values.imagePullSecrets -}}
##############################################################################
WARNING: .Values.imagePullSecrets is deprecated.
  Please move your pull secrets to .Values.global.imagePullSecrets instead.
  The top-level imagePullSecrets field will be removed in a future release.
##############################################################################
{{- end -}}
{{- end -}}

{{/*
Surface the legacy clickhouse-config.json deprecation when a customer is BYOing
the reader Secret. Helm cannot read Secret contents at template time, so this
fires unconditionally for BYO setups; the ui-backend logs the same notice at
runtime only when it actually loaded a legacy-format Secret.
*/}}
{{- define "management.clickhouseLegacyFormatWarning" -}}
{{- if not .Values.ui.backend.clickhouse.generateConfig -}}
##############################################################################
DEPRECATION: The legacy clickhouse-config Secret format (single config.json
  key) is deprecated. Please ensure your BYO Secret at
  ui.backend.clickhouse.secretRef={{ .Values.ui.backend.clickhouse.secretRef | quote }}
  uses the new flat-key format with one Secret key per field:

    stringData:
      address:  ...
      port:     "9000"
      database: ...
      username: ...
      password: ...

  The OTel telemetry collectors require flat keys; they cannot read
  config.json. The ui-backend still accepts legacy config.json but will log a
  deprecation warning at startup. See the chart README for migration.
##############################################################################
{{- end -}}
{{- end -}}

{{/*
File path that ui-backend and the agentevals subchart both read the Postgres
DSN from. Defaults to the chart-rendered Secret mount; operators who set
database.postgres.urlFile override with their own path.
*/}}
{{- define "management.postgresDsnFilePath" -}}
{{- default "/usr/share/management/postgres/url" .Values.database.postgres.urlFile -}}
{{- end -}}

{{/*
Name of the chart-generated Postgres DSN Secret. The current agentevals
subchart takes extra volume names as literal values, so its established static
Secret reference must be retained while that experimental integration is
enabled. Without a naming override, other installs retain the historical name.
*/}}
{{- define "management.postgresDsnSecretName" -}}
{{- if .Values.agentevals.enabled -}}
management-postgres-dsn
{{- else -}}
{{- include "management.overridableName" (dict "root" . "defaultName" "management-postgres-dsn" "suffix" "-postgres-dsn") -}}
{{- end -}}
{{- end -}}

{{/*
Emit an experimental notice when the agentevals integration is enabled.
*/}}
{{- define "management.agentevalsExperimentalWarning" -}}
{{- if .Values.agentevals.enabled -}}
##############################################################################
EXPERIMENTAL: the agentevals integration is enabled (agentevals.enabled=true).
  This integration is in active development and is NOT covered by upgrade or
  backwards-compatibility guarantees yet. Values keys, Secret shapes, and
  resource names may change between chart releases. Do not enable in
  production.

  REQUIRED PAIRING: agentevals.enabled here MUST be paired with
  controller.agentevals.enabled=true in your kagent-enterprise release. The
  kagent controller owns the `enterprise` PG schema agentevals migrations
  attach to. If only one side is enabled:

    - management on, kagent off  → ui-backend creates the CH `agentevals`
      database but eval handlers return Unavailable because the PG schema
      never gets migrated.
    - kagent on, management off  → PG schema is migrated but ui-backend has
      no AGENTEVALS_URL / EVALS_TRACE_PROXY_URL wired and the UI's
      Evaluations section is dark.

  Failure modes do NOT recover on their own; flipping both flags and
  re-running `helm upgrade` is required.
##############################################################################
{{- end -}}
{{- end -}}

{{/*
Surface the implicit mesh default-roles grant at install time. Renders only
when the default actually applies: mesh enabled and defaultRoles unset,
mirroring the resolution in rbac-config.yaml.
*/}}
{{- define "management.defaultRolesNotice" -}}
{{- if and .Values.products.mesh.enabled (kindIs "invalid" .Values.rbac.roleMapping.defaultRoles) -}}
##############################################################################
NOTICE: products.mesh.enabled is true and rbac.roleMapping.defaultRoles is
  unset, so every user who logs in through the configured OIDC provider is
  granted the global.Authenticated role: read-only access to the mesh UI
  (Fleet Graph, Global Services, Dashboard), the connected-cluster list, and
  their own user info, regardless of what roles their claims map to. Set
  rbac.roleMapping.defaultRoles explicitly to override; [] requires a mapped
  role for all access. See rbac.roleMapping in the chart README.
##############################################################################
{{- end -}}
{{- end -}}

{{/*
The Secret holding the MCP authorization server's signing key. Keeps its
historical name on a default install and follows an explicit naming override
for same-namespace multi-install.
*/}}
{{- define "management.meshMcpOAuthKeySecretName" -}}
{{- include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-mesh-mcp-oauth-key" "suffix" "-mesh-mcp-oauth-key") -}}
{{- end -}}

{{/*
The chart's own in-cluster UI URL. Follows the release's naming override, so
two installs in one namespace address their own Service.
*/}}
{{- define "management.inClusterUiUrl" -}}
{{- printf "http://%s.%s.svc.cluster.local" (include "management.uiServiceName" .) .Release.Namespace -}}
{{- end -}}

{{/*
The Service publishing the Mesh MCP endpoint, separate from the UI Service so
an install exposes it deliberately. Keeps its historical name on a default
install and follows a naming override like the other MCP objects.
*/}}
{{- define "management.meshMcpServiceName" -}}
{{- include "management.validatedServiceName" (dict "name" (include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-mesh-mcp" "suffix" "-mesh-mcp")) "root" .) -}}
{{- end -}}

{{/*
The MCP Service's in-cluster URL, the fallback resource address in-fleet
agents use. The port is omitted when it is 80.
*/}}
{{- define "management.inClusterMcpUrl" -}}
{{- $port := int ((((.Values.ui.backend).mcp).service).port | default 80) -}}
{{- $base := printf "http://%s.%s.svc.cluster.local" (include "management.meshMcpServiceName" .) .Release.Namespace -}}
{{- if eq $port 80 -}}
{{- $base -}}
{{- else -}}
{{- printf "%s:%d" $base $port -}}
{{- end -}}
{{- end -}}

{{/*
The canonical MCP audience, the MCP resource URI. Every request to the MCP
endpoint must present a token bound to this exact value. Mirrors the
backend's mcpAudience: ui.backend.mcp.publicUrl when set, otherwise the MCP
Service's in-cluster URL.
*/}}
{{- define "management.mcpAudience" -}}
{{- $base := (((.Values.ui.backend).mcp).publicUrl) | default (include "management.inClusterMcpUrl" .) | trimSuffix "/" -}}
{{- printf "%s/api/mcp" $base -}}
{{- end -}}

{{/*
Non-empty when an optional scalar value is set. nil and the empty string are
unset; a numeric 0 is set, which a bare `with` would drop (--set coerces
digits to integers, and 0 is falsy).
*/}}
{{- define "management.isSet" -}}
{{- if and (not (kindIs "invalid" .)) (ne (toString .) "") -}}
true
{{- end -}}
{{- end -}}

{{/*
Non-empty when the mesh agent-interfaces feature set is enabled: the master
flag for every surface of design/mesh/agent-interfaces.md.
*/}}
{{- define "management.agentInterfacesEnabled" -}}
{{- if index ((.Values.products.mesh).features | default dict) "agent-interfaces" -}}
true
{{- end -}}
{{- end -}}

{{/*
Non-empty when the Mesh MCP endpoint is served: the mesh product, the
agent-interfaces master flag, and the ui.backend.mcp.enabled flag are all on.
*/}}
{{- define "management.mcpEnabled" -}}
{{- if and .Values.products.mesh.enabled (include "management.agentInterfacesEnabled" .) ((.Values.ui.backend).mcp).enabled -}}
true
{{- end -}}
{{- end -}}

{{/*
Non-empty when the MCP endpoint's built-in authorization server is served:
the endpoint is served and ui.backend.mcp.oauth.enabled is not false.
*/}}
{{- define "management.mcpOAuthEnabled" -}}
{{- $oauth := (((.Values.ui.backend).mcp).oauth) | default dict -}}
{{- if and (include "management.mcpEnabled" .) (ne (toString $oauth.enabled) "false") -}}
true
{{- end -}}
{{- end -}}

{{/*
Surface the Mesh MCP endpoint, its Service, and its audience requirement at
install time.
*/}}
{{- define "management.meshMcpNotice" -}}
{{- if (include "management.mcpEnabled" .) -}}
{{- $mcp := ((.Values.ui.backend).mcp) | default dict -}}
{{- $svc := $mcp.service | default dict -}}
##############################################################################
NOTICE: the Mesh MCP server is enabled. It is published by its own Service,
  {{ include "management.meshMcpServiceName" . }} ({{ $svc.type | default "ClusterIP" }}, port {{ $svc.port | default 80 }}),
  separate from the UI Service, and serves /api/mcp. Every request must
  present a bearer token bound to the MCP audience
  ({{ include "management.mcpAudience" . }}). Requests are budgeted per
  user via ui.backend.agentLimits. See _docs/mesh-mcp-server.md.
{{- if not $mcp.publicUrl }}
  Set ui.backend.mcp.publicUrl when clients reach the endpoint from outside
  the cluster; until then the resource identifier is the in-cluster URL above.
{{- end }}
{{- if (include "management.mcpOAuthEnabled" .) }}

  Users can connect MCP clients such as Claude Code with their own sign-in:
  add {{ include "management.mcpAudience" . }} to the client and approve
  it in the mesh UI when the browser opens.
{{- if not .Values.ui.publicUrl }}
  Set ui.publicUrl to the URL users reach the UI at: the sign-in flow sends
  the browser there, and without it the consent page is addressed by the
  UI's in-cluster Service URL.
{{- end }}
{{- end }}
##############################################################################
{{- end -}}
{{- end -}}

{{/* Chart name */}}
{{- define "kagent-enterprise.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* Chart full name */}}
{{- define "kagent-enterprise.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := include "kagent-enterprise.name" . -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Base name for namespaced management resources, labels, and in-cluster DNS
references. The default preserves the chart's existing solo-enterprise-ui
resource names. Set nameOverride or fullnameOverride when multiple releases
must coexist in the same namespace.

Precedence: fullnameOverride > nameOverride > solo-enterprise-ui.
*/}}
{{- define "management.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride -}}
{{- else -}}
{{- default "solo-enterprise-ui" .Values.nameOverride -}}
{{- end -}}
{{- end -}}

{{/*
Return a historical resource name by default, or derive it from
management.fullname when nameOverride/fullnameOverride is explicitly set.
*/}}
{{- define "management.overridableName" -}}
{{- if or .root.Values.nameOverride .root.Values.fullnameOverride -}}
{{- printf "%s%s" (include "management.fullname" .root) .suffix -}}
{{- else -}}
{{- .defaultName -}}
{{- end -}}
{{- end -}}

{{/*
Name an RBAC resource for the release and its installation namespace. RBAC
objects are either cluster-scoped or may be created in namespaces shared by
multiple management installs, so the base resource name alone is not unique.
Usage: {{ include "management.rbacResourceName" (dict "root" . "name" "role") }}
*/}}
{{- define "management.rbacResourceName" -}}
{{- printf "%s-%s-%s-%s" (include "management.fullname" .root) .name .root.Release.Name .root.Release.Namespace -}}
{{- end -}}

{{/*
Assert a Service name fits the Kubernetes 63-character limit (a Service name must
be a valid DNS label, which cluster DNS caps at 63), then return it. Every Service
name helper routes through this, so a too-long name fails at construction time with
an actionable message — no separate validation list to keep in sync.
Usage: {{ include "management.validatedServiceName" (dict "name" $name "root" .) }}
*/}}
{{- define "management.validatedServiceName" -}}
{{- $name := .name -}}
{{- if gt (len $name) 63 -}}
{{- $base := include "management.fullname" .root -}}
{{- fail (printf (join "\n" (list
  "Service name %q would be %d characters, which exceeds the Kubernetes 63-character limit for Service names (a Service name must be a valid DNS label, and cluster DNS caps a label at 63 characters)."
  ""
  "The base name (management.fullname) is currently %q (%d chars); shorten it by at least %d character(s)."
  ""
  "Set a shorter nameOverride or fullnameOverride. When running multiple installs in one namespace, give each install a DISTINCT value so their namespaced resources don't collide."
  )) $name (len $name) $base (len $base) (sub (len $name) 63)) -}}
{{- end -}}
{{- $name -}}
{{- end -}}

{{/*
Service names. Defined once here and consumed by the Service/StatefulSet templates.
Each self-validates its length (via management.validatedServiceName), so the check
can never drift from the real names and there is no separate list to maintain.
*/}}
{{- define "management.uiServiceName" -}}
{{- include "management.validatedServiceName" (dict "name" (include "management.fullname" .) "root" .) -}}
{{- end -}}
{{- define "management.metricsServiceName" -}}
{{- include "management.validatedServiceName" (dict "name" (printf "%s-metrics" (include "management.fullname" .)) "root" .) -}}
{{- end -}}
{{- define "management.telemetryGatewayServiceName" -}}
{{- $name := include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-telemetry-gateway" "suffix" "-telemetry-gateway") -}}
{{- include "management.validatedServiceName" (dict "name" $name "root" .) -}}
{{- end -}}
{{- define "management.telemetryCollectorName" -}}
{{- include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-telemetry-collector" "suffix" "-telemetry-collector") -}}
{{- end -}}
{{- define "management.telemetryCollectorServiceName" -}}
{{- include "management.validatedServiceName" (dict "name" (include "management.telemetryCollectorName" .) "root" .) -}}
{{- end -}}
{{- define "management.telemetryCollectorHeadlessServiceName" -}}
{{- $name := include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-telemetry-collector-headless" "suffix" "-telemetry-collector-headless") -}}
{{- include "management.validatedServiceName" (dict "name" $name "root" .) -}}
{{- end -}}

{{/*
Name of the chart-generated ClickHouse credentials Secret. Preserves the
historical default and follows an explicit naming override for same-namespace
multi-install. Consumers may independently set `secretRef` for BYO credentials.
*/}}
{{- define "management.clickhouseSecretName" -}}
{{- include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-clickhouse-config" "suffix" "-clickhouse-config") -}}
{{- end -}}

{{/*
Name of the Secret holding the Solo Enterprise license key. Preserves the
historical default, follows an explicit naming override for same-namespace
multi-install, and allows licensing.secretName to select a BYO Secret.
*/}}
{{- define "management.licenseSecretName" -}}
{{- .Values.licensing.secretName | default (include "management.overridableName" (dict "root" . "defaultName" "license-keys" "suffix" "-license-keys")) -}}
{{- end -}}

{{/*
Name of the ConfigMap holding the RBAC role-mapping config. Preserves the
historical default and follows an explicit naming override. The ui-backend reads
this name from RBAC_CONFIG_MAP_NAME (see deployment.yaml); keep the two in sync.
*/}}
{{- define "management.rbacConfigMapName" -}}
{{- include "management.overridableName" (dict "root" . "defaultName" "rbac-config-management" "suffix" "-rbac-config") -}}
{{- end -}}

{{- define "management.oidcSecretName" -}}
{{- if eq .Values.ui.backend.oidc.secretRef "ui-backend-oidc-secret" -}}
{{- include "management.overridableName" (dict "root" . "defaultName" "ui-backend-oidc-secret" "suffix" "-oidc-secret") -}}
{{- else -}}
{{- .Values.ui.backend.oidc.secretRef -}}
{{- end -}}
{{- end -}}

{{- define "management.k8sobjectsConfigMapName" -}}
{{- include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-k8sobjects-config" "suffix" "-k8sobjects-config") -}}
{{- end -}}

{{- define "management.telemetryCollectorConfigMapName" -}}
{{- include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-telemetry-collector-config" "suffix" "-telemetry-collector-config") -}}
{{- end -}}

{{- define "management.telemetryCollectorQueueClaimName" -}}
{{- include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-telemetry-collector-queue" "suffix" "-telemetry-collector-queue") -}}
{{- end -}}

{{/*
Names for the tunnel server workload, its three Services, and its auth Secret.
The Service names self-validate their length like the other Service helpers.
*/}}
{{- define "management.tunnelName" -}}
{{- include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-tunnel" "suffix" "-tunnel") -}}
{{- end -}}
{{- define "management.tunnelServiceName" -}}
{{- include "management.validatedServiceName" (dict "name" (include "management.tunnelName" .) "root" .) -}}
{{- end -}}
{{- define "management.tunnelInternalServiceName" -}}
{{- $name := include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-tunnel-internal" "suffix" "-tunnel-internal") -}}
{{- include "management.validatedServiceName" (dict "name" $name "root" .) -}}
{{- end -}}
{{- define "management.tunnelHeadlessServiceName" -}}
{{- $name := include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-tunnel-headless" "suffix" "-tunnel-headless") -}}
{{- include "management.validatedServiceName" (dict "name" $name "root" .) -}}
{{- end -}}
{{- define "management.tunnelAuthSecretName" -}}
{{- .Values.tunnelserver.authSecretRef | default (include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-tunnel-auth" "suffix" "-tunnel-auth")) -}}
{{- end -}}

{{/*
The internal tunnel auth token: the existing Secret's value on upgrade, a
fresh random value otherwise. The Secret stores it, and both consuming
Deployments hash it into a checksum annotation so a token change rolls them.
The value is resolved once per render and memoized on .Values, which every
template of this chart shares; without that each include would draw its own
random token and the annotations would disagree with the Secret, rolling both
Deployments on the first no-op upgrade. lookup is inert in template-only
pipelines (helm template, ArgoCD), which therefore regenerate the token and
roll both Deployments on every sync; tunnelserver.authSecretRef avoids that.
*/}}
{{- define "management.tunnelAuthToken" -}}
{{- if not (hasKey .Values "_renderedTunnelAuthToken") -}}
{{- $token := "" -}}
{{- if .Release.IsUpgrade -}}
{{- with lookup "v1" "Secret" .Release.Namespace (include "management.tunnelAuthSecretName" .) -}}
{{- $token = index .data "token" | default "" -}}
{{- end -}}
{{- end -}}
{{- if not $token -}}
{{- $token = randAlphaNum 43 | b64enc -}}
{{- end -}}
{{- $_ := set .Values "_renderedTunnelAuthToken" $token -}}
{{- end -}}
{{- index .Values "_renderedTunnelAuthToken" -}}
{{- end -}}

{{/*
Names for the k8sobjects collector workload, its metrics Service, its
persistent queue claim, and the Lease its replicas elect on. The Lease is
named with the workload so two installs in one namespace elect independently.
*/}}
{{- define "management.k8sobjectsCollectorName" -}}
{{- include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-k8sobjects-collector" "suffix" "-k8sobjects-collector") -}}
{{- end -}}
{{- define "management.k8sobjectsCollectorMetricsServiceName" -}}
{{- $name := include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-k8sobjects-collector-metrics" "suffix" "-k8sobjects-collector-metrics") -}}
{{- include "management.validatedServiceName" (dict "name" $name "root" .) -}}
{{- end -}}
{{- define "management.k8sobjectsQueueClaimName" -}}
{{- include "management.overridableName" (dict "root" . "defaultName" "solo-enterprise-k8sobjects-queue" "suffix" "-k8sobjects-queue") -}}
{{- end -}}

{{/* Common labels */}}
{{- define "kagent-enterprise.labels" -}}
app.kubernetes.io/name: {{ include "kagent-enterprise.name" . }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Pod labels that enroll a pod in Istio ambient mesh. Empty when
istio.ambient.enabled is false, so the gate controls emission without changing
indentation in the caller.
Usage:
  {{- with (include "solo-enterprise.ambientPodLabels" .) }}
  {{- . | nindent 8 }}
  {{- end }}
*/}}
{{- define "solo-enterprise.ambientPodLabels" -}}
{{- if ((.Values.istio).ambient).enabled -}}
istio.io/dataplane-mode: ambient
{{- end -}}
{{- end -}}

{{/*
Service labels that expose a Service cross-cluster via Istio multi-cluster
(east/west) routing. Only apply to Services that need a global FQDN.
Usage:
  {{- with (include "solo-enterprise.globalServiceLabels" .) }}
  {{- . | nindent 4 }}
  {{- end }}
*/}}
{{- define "solo-enterprise.globalServiceLabels" -}}
{{- if ((.Values.istio).ambient).enabled -}}
solo.io/service-scope: global
{{- end -}}
{{- end -}}

{{/*
Render container resources block.
Usage: {{ include "solo-enterprise.resources" .Values.tunnelserver.resources }}
*/}}
{{- define "solo-enterprise.resources" -}}
{{- if and . (not (empty .)) }}
resources:
{{- if and .requests (not (empty .requests)) }}
  requests:
    cpu: "{{ .requests.cpu }}"
    memory: "{{ .requests.memory }}"
{{- end }}
{{- if and .limits (not (empty .limits)) }}
  limits:
    cpu: "{{ .limits.cpu }}"
    memory: "{{ .limits.memory }}"
{{- end }}
{{- end }}
{{- end }}

{{/*
Render a self-monitoring Prometheus scrape_config entry.
Accepts a dict with keys: jobName, target, root (the root context for sharding).
Optional key: noSharding (bool) - skip sharding relabel for targets like localhost
that must be scraped by every replica independently.
Usage: {{ include "management.selfMonitoringScrapeConfig" (dict "jobName" "ui-backend" "target" "host:port" "root" .) }}
*/}}
{{- define "management.selfMonitoringScrapeConfig" -}}
- job_name: {{ .jobName }}
  static_configs:
    - targets:
        - {{ .target }}
  {{- if not .noSharding }}
  {{- with (include "management.collectorShardingRelabel" .root) }}
  relabel_configs:
    {{- . | nindent 4 }}
  {{- end }}
  {{- end }}
{{- end }}

{{/*
Render probe configuration options (timing and thresholds).
Usage: {{ include "solo-enterprise.probeOptions" .Values.tunnelserver.livenessProbe }}
*/}}
{{- define "solo-enterprise.probeOptions" -}}
{{- if .initialDelaySeconds | empty | not }}
initialDelaySeconds: {{ .initialDelaySeconds }}
{{- end }}
{{- if .periodSeconds | empty | not }}
periodSeconds: {{ .periodSeconds }}
{{- end }}
{{- if .timeoutSeconds | empty | not }}
timeoutSeconds: {{ .timeoutSeconds }}
{{- end }}
{{- if .successThreshold | empty | not }}
successThreshold: {{ .successThreshold }}
{{- end }}
{{- if .failureThreshold | empty | not }}
failureThreshold: {{ .failureThreshold }}
{{- end }}
{{- end }}

{{/*
Returns "true" if multi-cluster mode is supported by the enabled product set.

Multi-cluster is enabled by default. It is disabled only when at least one
single-cluster-only product is enabled and no multi-cluster product is enabled.

Multi-cluster-capable products: kagent, mesh
Single-cluster-only products:   agentgateway
*/}}
{{- define "solo-enterprise.isProductMultiCluster" -}}
{{- $productTypes := dict "kagent" "multi" "mesh" "multi" "agentgateway" "single" -}}
{{- $anyMultiCluster := false -}}
{{- $anySingleCluster := false -}}
{{- range $name, $type := $productTypes -}}
  {{- $product := index $.Values.products $name -}}
  {{- if and $product $product.enabled -}}
    {{- if eq $type "multi" -}}{{- $anyMultiCluster = true -}}{{- end -}}
    {{- if eq $type "single" -}}{{- $anySingleCluster = true -}}{{- end -}}
  {{- end -}}
{{- end -}}
{{- if or $anyMultiCluster (not $anySingleCluster) -}}
true
{{- end -}}
{{- end }}

{{/*
Returns "true" if multi-cluster mode is effectively enabled.

Both conditions must hold:
  - at least one enabled product supports multi-cluster (solo-enterprise.isProductMultiCluster), AND
  - the user has not explicitly disabled it via platform.multiCluster.enabled

Uses `eq false` rather than `default true` — Helm treats `false` as falsy,
so `default true false` would incorrectly return true.
*/}}
{{- define "solo-enterprise.isMultiClusterEnabled" -}}
{{- if and (include "solo-enterprise.isProductMultiCluster" .) (not (eq false .Values.platform.multiCluster.enabled)) -}}
true
{{- end -}}
{{- end }}

{{- define "solo-enterprise.autoAuthEnabled" -}}
{{- if empty .Values.oidc.issuer -}}
true
{{- end }}
{{- end }}

{{- define "solo-enterprise.autoAuthBaseURL" -}}
{{- printf "http://%s.%s.svc.cluster.local:5556" (include "management.uiServiceName" .) .Release.Namespace -}}
{{- end }}

{{- define "solo-enterprise.oidc.issuer" -}}
{{- if (include "solo-enterprise.autoAuthEnabled" .) -}}
{{- include "solo-enterprise.autoAuthBaseURL" . | quote }}
{{ else }}
{{- .Values.oidc.issuer | quote }}
{{- end }}
{{- end }}

{{/* Create a full image reference for telemetry collector */}}
{{- define "telemetry-collector.image" -}}
{{- $registry := .Values.telemetry.image.registry }}
{{- $repository := .Values.telemetry.image.repository }}
{{- $name := .Values.telemetry.image.name }}
{{- $tag := .Values.telemetry.image.tag }}
{{- printf "%s/%s/%s:%s" $registry $repository $name $tag }}
{{- end }}

{{/*
Comma separated string of namespaces to watch (watchNamespaces + Release.Namespace, deduplicated).
Usage:
{{- $namespacesStr := (include "management.watchNamespaces" .) -}}
{{- if $namespacesStr -}}
{{- range $ns := splitList "," $namespacesStr }}
...
{{- end }}
{{- end }}
*/}}
{{- define "management.watchNamespaces" -}}
{{- $list := .Values.kubernetes.watchNamespaces | default (list) -}}
{{- if gt (len $list) 0 }}
{{- if and .Values.products.agentgateway.enabled .Values.products.agentgateway.namespace -}}
{{- $list = append $list .Values.products.agentgateway.namespace -}}
{{- end -}}
{{- if and .Values.products.kagent.enabled .Values.products.kagent.namespace -}}
{{- $list = append $list .Values.products.kagent.namespace -}}
{{- end -}}
{{- join "," (append $list .Release.Namespace | uniq) -}}
{{- end }}
{{- end }}

{{/*
Every object the k8sobjects receiver can watch, in the order the receiver
config lists them. The receiver config and the collector's read-only RBAC both
render from this list, so a kind added here is watched and permitted together.
scope is cluster or namespaced. gate names the product that enables the entry
when watchNamespaces narrows the install; core entries are always on.
*/}}
{{- define "management.k8sobjectsCatalog" -}}
{{- toJson (list
  (dict "gate" "core" "scope" "namespaced" "group" "" "name" "services")
  (dict "gate" "core" "scope" "namespaced" "group" "" "name" "pods")
  (dict "gate" "core" "scope" "namespaced" "group" "" "name" "endpoints")
  (dict "gate" "core" "scope" "namespaced" "group" "" "name" "configmaps")
  (dict "gate" "core" "scope" "namespaced" "group" "" "name" "serviceaccounts")
  (dict "gate" "core" "scope" "namespaced" "group" "apps" "name" "deployments")
  (dict "gate" "core" "scope" "namespaced" "group" "apps" "name" "replicasets")
  (dict "gate" "core" "scope" "namespaced" "group" "apps" "name" "statefulsets")
  (dict "gate" "core" "scope" "namespaced" "group" "apps" "name" "daemonsets")
  (dict "gate" "core" "scope" "namespaced" "group" "autoscaling" "name" "horizontalpodautoscalers")
  (dict "gate" "core" "scope" "namespaced" "group" "discovery.k8s.io" "name" "endpointslices")
  (dict "gate" "core" "scope" "namespaced" "group" "networking.k8s.io" "name" "ingresses")
  (dict "gate" "core" "scope" "namespaced" "group" "networking.k8s.io" "name" "networkpolicies")
  (dict "gate" "core" "scope" "cluster" "group" "apiextensions.k8s.io" "name" "customresourcedefinitions")
  (dict "gate" "kagent" "scope" "namespaced" "group" "kagent.dev" "name" "agents")
  (dict "gate" "kagent" "scope" "namespaced" "group" "kagent.dev" "name" "memories")
  (dict "gate" "kagent" "scope" "namespaced" "group" "kagent.dev" "name" "modelconfigs")
  (dict "gate" "kagent" "scope" "namespaced" "group" "kagent.dev" "name" "toolservers")
  (dict "gate" "kagent" "scope" "namespaced" "group" "policy.kagent-enterprise.solo.io" "name" "accesspolicies")
  (dict "gate" "agentgateway" "scope" "cluster" "group" "gateway.networking.k8s.io" "name" "gatewayclasses")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "agentgateway.dev" "name" "agentgatewaybackends")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "agentgateway.dev" "name" "agentgatewaypolicies")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "agentgateway.dev" "name" "agentgatewayparameters")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "enterpriseagentgateway.solo.io" "name" "enterpriseagentgatewayparameters")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "enterpriseagentgateway.solo.io" "name" "enterpriseagentgatewaypolicies")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "enterpriseagentgateway.solo.io" "name" "enterpriseagentgatewaybackends")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "gateway.networking.k8s.io" "name" "gateways")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "gateway.networking.k8s.io" "name" "httproutes")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "gateway.networking.k8s.io" "name" "grpcroutes")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "gateway.networking.k8s.io" "name" "tcproutes")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "gateway.networking.k8s.io" "name" "tlsroutes")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "gateway.networking.k8s.io" "name" "referencegrants")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "gateway.networking.k8s.io" "name" "udproutes")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "gateway.networking.k8s.io" "name" "backendtlspolicies")
  (dict "gate" "agentgateway" "scope" "namespaced" "group" "gloo.solo.io" "name" "glootrafficpolicies")
  (dict "gate" "mesh" "scope" "cluster" "group" "" "name" "namespaces")
  (dict "gate" "mesh" "scope" "cluster" "group" "" "name" "nodes")
  (dict "gate" "mesh" "scope" "namespaced" "group" "networking.istio.io" "name" "virtualservices")
  (dict "gate" "mesh" "scope" "namespaced" "group" "networking.istio.io" "name" "destinationrules")
  (dict "gate" "mesh" "scope" "namespaced" "group" "networking.istio.io" "name" "gateways")
  (dict "gate" "mesh" "scope" "namespaced" "group" "networking.istio.io" "name" "serviceentries")
  (dict "gate" "mesh" "scope" "namespaced" "group" "networking.istio.io" "name" "sidecars")
  (dict "gate" "mesh" "scope" "namespaced" "group" "networking.istio.io" "name" "envoyfilters")
  (dict "gate" "mesh" "scope" "namespaced" "group" "networking.istio.io" "name" "workloadentries")
  (dict "gate" "mesh" "scope" "namespaced" "group" "networking.istio.io" "name" "workloadgroups")
  (dict "gate" "mesh" "scope" "namespaced" "group" "networking.istio.io" "name" "proxyconfigs")
  (dict "gate" "mesh" "scope" "namespaced" "group" "security.istio.io" "name" "authorizationpolicies")
  (dict "gate" "mesh" "scope" "namespaced" "group" "security.istio.io" "name" "peerauthentications")
  (dict "gate" "mesh" "scope" "namespaced" "group" "security.istio.io" "name" "requestauthentications")
  (dict "gate" "mesh" "scope" "namespaced" "group" "telemetry.istio.io" "name" "telemetries")
  (dict "gate" "mesh" "scope" "namespaced" "group" "extensions.istio.io" "name" "wasmplugins")
  (dict "gate" "mesh" "scope" "namespaced" "group" "admin.istio.io" "name" "segments")
  (dict "gate" "mesh" "scope" "namespaced" "group" "admin.solo.io" "name" "segments")
) -}}
{{- end -}}

{{/*
The catalog entries this install watches, as JSON. Every entry renders when the
install watches the whole cluster. When watchNamespaces narrows it, only
namespaced entries render, and only for enabled products.
*/}}
{{- define "management.k8sobjectsWatchedObjects" -}}
{{- $scoped := gt (len (include "management.watchNamespaces" .)) 0 -}}
{{- $products := .Values.products -}}
{{- $objects := list -}}
{{- range (include "management.k8sobjectsCatalog" . | fromJsonArray) -}}
{{- $enabled := or (eq .gate "core") (and (eq .gate "kagent") $products.kagent.enabled) (and (eq .gate "agentgateway") $products.agentgateway.enabled) (and (eq .gate "mesh") $products.mesh.enabled) -}}
{{- if or (not $scoped) (and $enabled (eq .scope "namespaced")) -}}
{{- $objects = append $objects . -}}
{{- end -}}
{{- end -}}
{{- toJson $objects -}}
{{- end -}}

{{/*
Read-only RBAC rules for a list of catalog entries, one rule per API group.
Args: the entries as a list.
*/}}
{{- define "management.k8sobjectsReadRules" -}}
{{- $byGroup := dict -}}
{{- range . -}}
{{- $_ := set $byGroup .group (append (index $byGroup .group | default list) .name) -}}
{{- end -}}
{{- range $group, $names := $byGroup }}
- apiGroups:
    - {{ $group | quote }}
  resources:
    {{- range $names }}
    - {{ . }}
    {{- end }}
  verbs:
    - get
    - list
    - watch
{{- end }}
{{- end -}}

{{/*
Render namespaces block for k8sobjects collector.
Usage: {{ include "management.k8sobjectsNamespaces" . }}
*/}}
{{- define "management.k8sobjectsNamespaces" -}}
{{- $namespacesStr := include "management.watchNamespaces" . -}}
{{- if gt (len $namespacesStr) 0 -}}
namespaces:
  {{- range $ns := splitList "," $namespacesStr }}
- {{ $ns | quote }}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Effective enablement of the two telemetry signals, after the product gate.

Each signal only has a consumer under specific products, so the operator-facing
telemetry.*.enabled flags are necessary but not sufficient:
  - metrics are Prometheus scrapes of the Istio data plane, read by the mesh UI
  - traces are GenAI spans, read by the kagent and agentgateway UIs
Enabling a signal whose product is off would scrape, ship, and store data that
nothing reads, so the gate is silent rather than a render failure: the flags
default to true and must stay harmless on a single-product install.

Both render "true" or the empty string, so callers use them as booleans:
  {{- if (include "management.metricsEnabled" .) }}
*/}}
{{- define "management.metricsEnabled" -}}
{{- if and .Values.telemetry.metrics.enabled .Values.products.mesh.enabled -}}
true
{{- end -}}
{{- end -}}

{{- define "management.tracesEnabled" -}}
{{- if and .Values.telemetry.traces.enabled (or .Values.products.kagent.enabled .Values.products.agentgateway.enabled) -}}
true
{{- end -}}
{{- end -}}

{{/*
Sharding relabel configs for the telemetry collector.
Uses hashmod to distribute targets across StatefulSet replicas.
Each replica's POD_ORDINAL env var determines which targets it scrapes.
Usage: {{ include "management.collectorShardingRelabel" . | nindent 12 }}

IMPORTANT: Scaling collectors requires `helm upgrade`. Do not use `kubectl scale`.
The modulus value in the ConfigMap must match the replica count. Manual scaling can break sharding.
*/}}
{{- define "management.collectorShardingRelabel" -}}
{{- if and (include "management.metricsEnabled" .) .Values.telemetry.collector.sharding.enabled }}
# Sharding relabel configs - distribute targets across {{ .Values.telemetry.collector.replicaCount }} replicas
- source_labels: [{{ default "__address__" .Values.telemetry.collector.sharding.label }}]
  modulus: {{ default 1 .Values.telemetry.collector.replicaCount }}
  target_label: __tmp_shard_id
  action: hashmod
- source_labels: [__tmp_shard_id]
  regex: ${env:POD_ORDINAL}
  action: keep
- action: labeldrop
  regex: __tmp_shard_id
{{- end }}
{{- end }}

{{/*
Render clickhouse service address. clickhouse.external is the single source
of endpoint truth when enabled; otherwise ui.backend.clickhouse.address, then
the bundled Service.
*/}}
{{- define "clickhouse.address" -}}
{{- if .Values.clickhouse.external.enabled }}
{{- .Values.clickhouse.external.address -}}
{{- else if not .Values.ui.backend.clickhouse.address }}
{{- .Release.Name }}-clickhouse.{{ .Release.Namespace }}.svc.cluster.local
{{- else }}
{{- .Values.ui.backend.clickhouse.address -}}
{{- end }}
{{- end }}

{{/*
Native protocol port for ui-backend, dbctl, and the collector exporters.
*/}}
{{- define "clickhouse.nativePort" -}}
{{- if .Values.clickhouse.external.enabled }}
{{- .Values.clickhouse.external.port -}}
{{- else }}
{{- .Values.ui.backend.clickhouse.port -}}
{{- end }}
{{- end }}

{{/*
Query parameters for the OTel ClickHouse exporter endpoints. TLS rides the
DSN secure flag; a private CA is configured through the exporter tls block
(clickhouse.exporterTLS).
*/}}
{{- define "clickhouse.exporterEndpointParams" -}}
dial_timeout=10s&enable_json_type=1
{{- if and .Values.clickhouse.external.enabled .Values.clickhouse.external.tls.enabled -}}
&secure=true
{{- end -}}
{{- end }}

{{/*
Exporter-level TLS block for a private CA. The referenced file is the ca.crt
key of the mounted clickhouse-config Secret.
*/}}
{{- define "clickhouse.exporterTLS" -}}
{{- if and .Values.clickhouse.external.enabled .Values.clickhouse.external.tls.enabled .Values.clickhouse.external.tls.ca -}}
tls:
  ca_file: /etc/clickhouse-config/ca.crt
{{- end -}}
{{- end }}


{{/*
Render the chart-generated reader Secret stringData. Used by
clickhouse-config-secret.yaml AND by checksum/clickhouse-secret pod-template
annotations so pods roll when the projected credentials change. Encapsulating
this here keeps the checksum off `include $.Template.BasePath/...`, which
breaks helm-unittest suites scoped to a single template.
*/}}
{{- define "clickhouse.secretData" -}}
address: {{ quote (include "clickhouse.address" .) }}
port: {{ quote (include "clickhouse.nativePort" .) }}
database: {{ quote .Values.ui.backend.clickhouse.database }}
username: {{ quote .Values.ui.backend.clickhouse.username }}
password: {{ quote .Values.ui.backend.clickhouse.password }}
{{- if .Values.clickhouse.external.enabled }}
tls: {{ quote (.Values.clickhouse.external.tls.enabled | toString) }}
{{- with .Values.clickhouse.external.tls.ca }}
ca.crt: {{ toJson . }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Stable signature of the values that drive the OTel collector ConfigMaps
(both telemetry-collector and k8sobjects). Used by checksum annotations on
the pod templates so changes to telemetry/products/traces/kubernetes values
force a pod rollout, without depending on a cross-template `include` that
would break helm-unittest suites scoped to a single template.

Over-broad on purpose: hashing the whole subtree is acceptable here because
a pod rollout on any helm-managed change is the desired behavior.
*/}}
{{- define "telemetry.configSignature" -}}
{{ .Values.cluster }}
{{ toYaml .Values.telemetry }}
{{ toYaml .Values.products }}
{{ toYaml .Values.traces }}
{{ toYaml .Values.kubernetes }}
{{ toYaml .Values.ui.backend.metrics }}
{{- end }}

{{/*
Upgrade notice for the tunnel split. The pre-upgrade UI Service still carries
the tunnel port when lookup sees it, which is exactly the upgrade that moves
the port to the tunnel Service and needs every relay repointed. lookup is
inert in template-only pipelines, where the notice simply does not render.
*/}}
{{- define "management.tunnelRepointWarning" -}}
{{- if and .Release.IsUpgrade (include "solo-enterprise.isMultiClusterEnabled" .) }}
{{- with lookup "v1" "Service" .Release.Namespace (include "management.uiServiceName" .) }}
{{- range (.spec).ports }}
{{- if eq .name "tunnel" }}

WARNING: this upgrade moves the tunnel server out of the solo-enterprise-ui pod
and removes port 9000 from the {{ include "management.uiServiceName" $ }} Service. Every relay whose
tunnel.fqdn still points at that Service reports its cluster as disconnected,
and live Kubernetes reads for it fail, until it is repointed at the
{{ include "management.tunnelServiceName" $ }} Service (or the DNS name in front of it is moved):

  kubectl get svc -n {{ $.Release.Namespace }} {{ include "management.tunnelServiceName" $ }} \
    -o jsonpath="{.status.loadBalancer.ingress[0]['hostname','ip']}"

Telemetry keeps flowing over OTLP in the meantime. See _docs/platform/ha-dr.md.
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
Converts a Kubernetes quantity such as 10Gi or 1.5Ti to bytes. Fails on forms
the chart cannot size a queue volume from.
*/}}
{{- define "solo-enterprise.quantityBytes" -}}
{{- $q := toString . -}}
{{- $num := regexFind `^[0-9]+(\.[0-9]+)?` $q -}}
{{- $unit := trimPrefix $num $q -}}
{{- $units := dict "" 1 "k" 1000 "M" 1000000 "G" 1000000000 "T" 1000000000000 "Ki" 1024 "Mi" 1048576 "Gi" 1073741824 "Ti" 1099511627776 -}}
{{- if or (eq $num "") (not (hasKey $units $unit)) -}}
{{- fail (printf "cannot convert quantity %q to bytes: use a whole or decimal number with one of k, M, G, T, Ki, Mi, Gi, or Ti" $q) -}}
{{- end -}}
{{- $parts := splitList "." $num -}}
{{- $frac := "" -}}
{{- if gt (len $parts) 1 -}}{{- $frac = index $parts 1 -}}{{- end -}}
{{- $scale := 1 -}}
{{- range until (len $frac) -}}{{- $scale = mul $scale 10 -}}{{- end -}}
{{- $mantissa := regexReplaceAll "^0+" (printf "%s%s" (index $parts 0) $frac) "" | default "0" -}}
{{- div (mul (int64 $mantissa) (get $units $unit)) $scale -}}
{{- end -}}

{{/*
On-disk budget for the queue files on one queue volume: 85% of its size, which
leaves room for filesystem overhead and the compaction copy.
*/}}
{{- define "solo-enterprise.queueDiskBudget" -}}
{{- $bytes := include "solo-enterprise.quantityBytes" . | int64 -}}
{{- div (mul $bytes 85) 100 -}}
{{- end -}}

{{/*
Number of persistent queue files on the management telemetry collector's
volume. The persistent queue opens one bbolt file per exporter per signal, so
clickhouse/k8sobjects and clickhouse/metrics add one each and
clickhouse/telemetry adds one for logs plus one for traces when traces are
collected.
*/}}
{{- define "management.telemetryCollectorQueueFiles" -}}
{{- if (include "management.tracesEnabled" .) -}}4{{- else -}}3{{- end -}}
{{- end -}}

{{/*
Byte cap for one queue file: an equal share of the volume's disk budget across
the queue files that share it, one per exporter per signal. Args: dict "size"
<volume quantity> "files" <number of queue files on the volume>.
*/}}
{{- define "solo-enterprise.queueFileMaxSize" -}}
{{- div (include "solo-enterprise.queueDiskBudget" .size | int64) (max 1 (int .files)) -}}
{{- end -}}

{{/*
Renders the file_storage extension for a persistent queue volume with the
per-file cap and rebound compaction. Args as for solo-enterprise.queueFileMaxSize.
*/}}
{{- define "solo-enterprise.queueFileStorage" -}}
{{- $maxSize := include "solo-enterprise.queueFileMaxSize" . | int64 -}}
file_storage:
  directory: /var/lib/otelcol/queue
  create_directory: true
  # Hard cap per queue file so the store cannot outgrow the volume. A full
  # store rejects a batch the same way a full queue does.
  max_size: {{ $maxSize }}
  # Compaction reclaims space after a drained backlog. It runs online only,
  # since a start-time copy could equal the whole file, and its temp copy
  # lives on the queue volume because the root filesystem is read-only.
  compaction:
    on_rebound: true
    directory: /var/lib/otelcol/queue/compaction
    cleanup_on_start: true
    rebound_needed_threshold_mib: {{ max 1 (div (div $maxSize 4) 1048576) }}
    rebound_trigger_threshold_mib: {{ max 1 (div (div $maxSize 20) 1048576) }}
{{- end -}}
