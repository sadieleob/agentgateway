<img src="https://img.shields.io/badge/Version-0.0.0-informational?style=flat-square" alt="Version: 0.0.0" align="left">

<br>Review Helm values for the `kagent-enterprise` Helm chart, which installs the Solo build of kagent open source.

## Overview

The kagent-enterprise chart deploys the Solo build of kagent open source, which installs core kagent components and specialized agents for Kubernetes environments including:
- kagent controller for managing agent lifecycles and configurations
- AI agents for Kubernetes (k8s, Istio, Helm, Argo Rollouts, Cilium, and more)
- MCP tools for extended functionality (Grafana)
- Built-in kagent tools

For more information, see the [installation guide](https://docs.solo.io/kagent/latest/install/install-kagent/).

## Required Values

The following values **must** be configured for the kagent-enterprise chart to function:

| Parameter | Description | Why Required |
|-----------|-------------|--------------|
| `oidc.issuer` | OIDC identity provider issuer URL | Required for user authentication |
| `oidc.clientId` | OIDC client identifier | Required for OAuth2/OIDC flow |
| `oidc.secret` or `oidc.secretRef` | OIDC client secret or reference to secret | Required for secure authentication |
| `providers.*.apiKey` or `providers.*.apiKeySecretRef` | API key for LLM providers (OpenAI, Anthropic, etc.) | Required for AI agent functionality |

## Values

| Key | Type | Description | Default |
| --- | ---- | ----------- | ------- |
| annotations | object | Additional annotations to add to all Kubernetes deployment resources | `{}` |
| argo-rollouts-agent.enabled | bool | Enable Argo Rollouts agent for progressive delivery | `false` |
| argo-rollouts-agent.memory.enabled | bool |  | `false` |
| argo-rollouts-agent.memory.modelConfigRef | string |  | `""` |
| argo-rollouts-agent.memory.ttlDays | int |  | `15` |
| argo-rollouts-agent.modelConfigRef | string |  | `""` |
| argo-rollouts-agent.resources | object | Resource requests and limits for argo-rollouts-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| cilium-debug-agent.enabled | bool | Enable Cilium debug agent for network troubleshooting | `false` |
| cilium-debug-agent.memory.enabled | bool |  | `false` |
| cilium-debug-agent.memory.modelConfigRef | string |  | `""` |
| cilium-debug-agent.memory.ttlDays | int |  | `15` |
| cilium-debug-agent.modelConfigRef | string |  | `""` |
| cilium-debug-agent.resources | object | Resource requests and limits for cilium-debug-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| cilium-manager-agent.enabled | bool | Enable Cilium manager agent for CNI management | `false` |
| cilium-manager-agent.memory.enabled | bool |  | `false` |
| cilium-manager-agent.memory.modelConfigRef | string |  | `""` |
| cilium-manager-agent.memory.ttlDays | int |  | `15` |
| cilium-manager-agent.modelConfigRef | string |  | `""` |
| cilium-manager-agent.resources | object | Resource requests and limits for cilium-manager-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| cilium-policy-agent.enabled | bool | Enable Cilium network policy agent | `false` |
| cilium-policy-agent.memory.enabled | bool |  | `false` |
| cilium-policy-agent.memory.modelConfigRef | string |  | `""` |
| cilium-policy-agent.memory.ttlDays | int |  | `15` |
| cilium-policy-agent.modelConfigRef | string |  | `""` |
| cilium-policy-agent.resources | object | Resource requests and limits for cilium-policy-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| controller.a2aBaseUrl | string | The base URL of the A2A Server endpoint, as advertised to clients. | `http://<fullname>-controller.<namespace>.svc:<port>` |
| controller.a2aClientTimeout | string | HTTP client timeout for A2A requests from the controller to agent pods. 0 (the default) means no timeout, which is correct for SSE-based streaming agents that can run for an arbitrarily long time. The previous implicit default was 3m (inherited from the a2a-go SDK), which caused `context deadline exceeded` errors for agents that take longer than 3 minutes to complete. Set a positive Go duration string (e.g. "30m", "1h") only if you need a hard upper bound on individual A2A calls. | "" (no timeout) |
| controller.affinity | object | [Affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#affinity-and-anti-affinity) rules for the controller pod. | `{}` |
| controller.agentDeployment | object | Global deployment defaults applied to all agent pods. Per-agent settings in the Agent CRD take precedence over these defaults. | `{"host":"","nodeSelector":{},"podLabels":{},"serviceAccountName":""}` |
| controller.agentDeployment.host | string | Default host address for agent pods to bind to. Leave empty to use the controller's default fallback of "0.0.0.0". Automatically set to "::" when ipv6.enabled is true. Can be explicitly overridden here regardless of the ipv6 flag. | "" (controller falls back to "0.0.0.0"; "::" when ipv6.enabled) |
| controller.agentDeployment.nodeSelector | object | Default nodeSelector applied to all agent deployments. Useful when admission policies require a nodeSelector on every Deployment, since wizard-created Agents carry none. A per-agent nodeSelector in the Agent CRD takes precedence over these defaults. | {} (no default nodeSelector) |
| controller.agentDeployment.podLabels | object | Default labels applied to all agent pod templates. Per-agent labels in the Agent CRD take precedence over these defaults. | {} (no extra labels) |
| controller.agentDeployment.serviceAccountName | string | Default ServiceAccount name for agent pods. When set, agent pods that don't specify an explicit serviceAccountName will use this ServiceAccount instead of creating a per-agent one. Useful for Workload Identity (GCP, AWS IRSA, Azure Workload Identity). Precedence: agent-level serviceAccountName > this default > auto-created SA. | "" (auto-create per-agent ServiceAccount) |
| controller.agentImage.pullPolicy | string | Image pull policy for agent images | `""` |
| controller.agentImage.pullSecret | string | Image pull secret name set on agent pods created by the controller | `""` |
| controller.agentImage.registry | string | Container registry for agent images | `""` |
| controller.agentImage.repository | string | Repository for agent images | `"kagent-dev/kagent/app"` |
| controller.agentImage.tag | string | Tag for agent images. | `"0.10.0-rc5"` |
| controller.agentevals.enabled | bool | EXPERIMENTAL. Enable the agentevals enterprise PG migration track in the controller. Must match `agentevals.enabled` in the management chart since the controller owns the `enterprise` schema that agentevals depends on. | `false` |
| controller.annotations | object | Additional annotations to add to the controller Deployment metadata | `{}` |
| controller.env | list | Additional environment variables for controller | `[]` |
| controller.envFrom | list | Additional envFrom sources for controller (e.g. secretRef). Controller ConfigMap is always included. | `[]` |
| controller.goAgentImage | object | The image used for the Go (ADK) runtime agent. | `{"pullPolicy":"","registry":"","repository":"kagent-dev/kagent/golang-adk","tag":"0.10.0-rc5"}` |
| controller.goAgentImage.tag | string | Tag for the Go (ADK) runtime agent image. | `"0.10.0-rc5"` |
| controller.image.name | string | Image name for the controller image. | `"kagent-enterprise-controller"` |
| controller.image.pullPolicy | string | Image pull policy for controller | `""` |
| controller.image.registry | string | Container registry for the controller image. | `"us-docker.pkg.dev/solo-public"` |
| controller.image.repository | string | Repository path for the controller image. | `"kagent-enterprise"` |
| controller.image.tag | string | Image tag for the controller image. If unset, defaults to the chart version. | `""` |
| controller.istioAuthzTranslation.enabled | bool | Enable Istio authorization for access policies and waypoint label on Agents | `false` |
| controller.loglevel | string | Log level for the controller (debug, info, warn, error) | `"info"` |
| controller.mcpEgressPlaintext | bool | Rewrite RemoteMCPServer tool URLs and the controller's tool-discovery dial from `https://host[:port]` to `http://host:<port-or-443>` so MCP traffic egresses in plaintext to a proxy that originates TLS upstream off by default. | `false` |
| controller.metrics | object | Prometheus-style /metrics endpoint for the controller manager. When enabled, provisions a dedicated metrics Service plus the ClusterRoles required for authenticated scrapes. Bind `<fullname>-metrics-reader` to your Prometheus ServiceAccount to grant scrape access. Use `bindAddress` for any port change: the Service `targetPort` and the pod `containerPort` are derived from it at template time, so overriding `METRICS_BIND_ADDRESS` via `controller.env` shifts only the runtime listener and leaves the rendered Service pointing at the chart-time port. Setting `bindAddress: "0"` (or empty) is treated as a disable signal — equivalent to `enabled: false` — to keep faith with the controller binary's documented contract for `--metrics-bind-address`. | disabled |
| controller.nodeSelector | object | Node labels to match for `Pod` [scheduling](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/). | `{}` |
| controller.pdb | object | [PodDisruptionBudget](https://kubernetes.io/docs/tasks/run-application/configure-pdb/) for the controller pods. Disabled by default: `controller.replicas` is 1, and a `minAvailable: 1` budget on a single-replica Deployment blocks every voluntary eviction, so node drains and cluster upgrades hang indefinitely. Raise `controller.replicas` before switching to `minAvailable`. | `{"annotations":{},"enabled":false,"labels":{},"maxUnavailable":1,"minAvailable":null,"unhealthyPodEvictionPolicy":""}` |
| controller.pdb.annotations | object | Annotations for the controller PodDisruptionBudget. | `{}` |
| controller.pdb.enabled | bool | Set to true to create the PodDisruptionBudget. | `false` |
| controller.pdb.labels | object | Additional labels for the controller PodDisruptionBudget. | `{}` |
| controller.pdb.maxUnavailable | int | Maximum number of pods that may be unavailable. Int or percentage string (e.g. `1` or `"50%"`). Mutually exclusive with `minAvailable`. | `1` |
| controller.pdb.minAvailable | string | Minimum number of pods that must remain available. Int or percentage string (e.g. `1` or `"50%"`). Mutually exclusive with `maxUnavailable`. | unset (`maxUnavailable` is used instead) |
| controller.pdb.unhealthyPodEvictionPolicy | string | `spec.unhealthyPodEvictionPolicy`, one of `IfHealthyBudget` (the Kubernetes default) or `AlwaysAllow`. `AlwaysAllow` lets unhealthy pods be evicted even when the budget is exhausted, which avoids drains wedging on a crash-looping pod. Requires Kubernetes >= 1.27. Omitted from the manifest when empty. | "" (defer to the Kubernetes default) |
| controller.podAnnotations | object | Node taints to be tolerated for `Pod` [scheduling](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/). | `{}` |
| controller.podLabels | object | Additional labels for the controller pod template, merged over the global `podLabels` (per-key; component keys win). Selector labels can never be overridden. | `{}` |
| controller.readinessProbe | object | Custom readiness probe for the controller container. Setting a value replaces the default probe entirely — include a handler (httpGet / exec / tcpSocket / grpc) when overriding. | httpGet /health on port http, periodSeconds=30 |
| controller.remoteJwksConfig | object | Remote JWKS source used by AccessPolicy UserGroup subjects that omit jwksKey. Explicit policy jwksKey.inline or jwksKey.remote values take precedence. Example: remoteJwksConfig:   serviceRef:     name: enterprise-agentgateway     namespace: gloo-system     port: 7777   path: /.well-known/jwks.json | `{}` |
| controller.replicas | int | Number of controller replicas | `1` |
| controller.resources | object | Resource requests and limits for controller | `{"limits":{"cpu":2,"memory":"512Mi"},"requests":{"cpu":"100m","memory":"128Mi"}}` |
| controller.service.annotations | object |  | `{}` |
| controller.service.ports.port | int | Service port for controller | `8083` |
| controller.service.ports.targetPort | int | Target port for controller | `8083` |
| controller.service.type | string | Service type for controller | `"ClusterIP"` |
| controller.serviceAccount | object | ServiceAccount settings for the controller pod | `{"annotations":{}}` |
| controller.serviceAccount.annotations | object | Annotations to add to the controller ServiceAccount. Useful for GCP Workload Identity, AWS IRSA, or Azure Workload Identity. | {} (no extra annotations) |
| controller.skillsInitImage | object | The image used by the skills-init container to clone skills from Git and pull OCI skill images. | `{"pullPolicy":"","registry":"","repository":"kagent-dev/kagent/skills-init","tag":"0.10.0-rc5"}` |
| controller.skillsInitImage.tag | string | Tag for the skills-init image. | `"0.10.0-rc5"` |
| controller.startupProbe | object | Custom startup probe for the controller container. Setting a value replaces the default probe entirely — include a handler (httpGet / exec / tcpSocket / grpc) when overriding. | httpGet /health on port http, periodSeconds=15, initialDelaySeconds=15 |
| controller.streaming | string | @deprecated Removed in 0.10.0. The A2A SDK now handles SSE buffering and timeouts internally. These values have no effect and will be removed in a future release. | `nil` |
| controller.substrate.ateApiEndpoint | string |  | `""` |
| controller.substrate.ateApiInsecure | bool |  | `false` |
| controller.substrate.ateApiServer.namespace | string |  | `"ate-system"` |
| controller.substrate.ateApiServer.serviceAccount | string |  | `"ate-api-server"` |
| controller.substrate.ateApiTokenAudience | string |  | `"api.ate-system.svc"` |
| controller.substrate.ateApiTokenExpirationSeconds | int |  | `3600` |
| controller.substrate.ateApiTokenFile | string |  | `"/var/run/secrets/tokens/ate-api/token"` |
| controller.substrate.atenetRouterURL | string |  | `""` |
| controller.substrate.defaultWorkerPool.name | string |  | `""` |
| controller.substrate.defaultWorkerPool.namespace | string |  | `""` |
| controller.substrate.enabled | bool |  | `false` |
| controller.tolerations | list | Node taints which will be tolerated for `Pod` [scheduling](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/). | `[]` |
| controller.toolRefreshInterval | string | How often MCP tool-discovery controllers requeue to refresh the discovered-tool cache (RemoteMCPServer, MCPServer, labeled MCP Service). Default 60s. | `"60s"` |
| controller.topologySpreadConstraints | list | [Topology spread constraints](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#pod-topology-spread-constraints) for the controller pod. | `[]` |
| controller.volumeMounts | list | Additional volumeMounts on the controller container. Useful for mounting license keys from external secret stores (e.g. CSI / Google Secret Manager). Required when using licensing.licenseFilePath. | `[]` |
| controller.volumes | list | Additional volumes on the controller Deployment. Useful for mounting license keys from external secret stores (e.g. CSI / Google Secret Manager). Required when using licensing.licenseFilePath. | `[]` |
| controller.watchNamespaces | list | Namespaces the controller should watch. If empty (default), the controller will watch ALL available namespaces. | [] |
| database.postgres.bundled | object | Bundled PostgreSQL instance — for development and evaluation only. Not suitable for production. Deployed when enabled is true and url/urlFile are not set. | `{"enabled":true,"image":{"name":"postgres","pullPolicy":"IfNotPresent","registry":"docker.io","repository":"library","tag":"18.6-alpine3.23"},"podSecurityContext":{"fsGroup":999,"runAsGroup":999,"runAsNonRoot":true,"runAsUser":999,"seccompProfile":{"type":"RuntimeDefault"}},"resources":{"limits":{"cpu":"500m","memory":"512Mi"},"requests":{"cpu":"250m","memory":"256Mi"}},"securityContext":{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]}},"storage":"500Mi","storageClassName":""}` |
| database.postgres.bundled.enabled | bool | Set to false to disable the bundled database and provide your own via url or urlFile. | `true` |
| database.postgres.bundled.image.name | string | Bundled PostgreSQL image name | `"postgres"` |
| database.postgres.bundled.image.pullPolicy | string | Bundled PostgreSQL image pull policy | `"IfNotPresent"` |
| database.postgres.bundled.image.registry | string | Bundled PostgreSQL image registry | `"docker.io"` |
| database.postgres.bundled.image.repository | string | Bundled PostgreSQL image repository (org/namespace) | `"library"` |
| database.postgres.bundled.image.tag | string | Bundled PostgreSQL image tag | `"18.6-alpine3.23"` |
| database.postgres.bundled.podSecurityContext | object | Pod-level security context for the bundled PostgreSQL deployment. | `{"fsGroup":999,"runAsGroup":999,"runAsNonRoot":true,"runAsUser":999,"seccompProfile":{"type":"RuntimeDefault"}}` |
| database.postgres.bundled.resources | object | Resource requests/limits for the demo PostgreSQL container | `{"limits":{"cpu":"500m","memory":"512Mi"},"requests":{"cpu":"250m","memory":"256Mi"}}` |
| database.postgres.bundled.securityContext | object | Container-level security context for the bundled PostgreSQL container. | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]}}` |
| database.postgres.bundled.storage | string | PersistentVolumeClaim size for demo PostgreSQL data | `"500Mi"` |
| database.postgres.bundled.storageClassName | string | StorageClass for the PostgreSQL PVC. Defaults to the cluster default when empty. | `""` |
| database.postgres.pool | object | Optional pgxpool settings. Leave unset/null to keep pgx library defaults (MaxConns≈max(4,NumCPU), MinConns=0, MaxConnIdleTime=30m, MaxConnLifetime=1h). | `{"maxConnIdleTime":"","maxConnLifetime":"","maxConns":null,"minConns":null}` |
| database.postgres.sessionRetentionDays | int | Hard-delete idle sessions (and cascaded events/tasks/checkpoints/shares) after N days of no activity. Uses session.updated_at as a sliding idle clock (writes refresh it). 0 disables cleanup (default, existing installs unchanged). | `0` |
| database.postgres.skipMigrations | bool | Skip running database migrations at controller startup. The controller instead verifies the database is already migrated and fails if it is not. Migrations must be applied out-of-band (e.g. from a CI/CD pipeline) before install/upgrade. | `false` |
| database.postgres.url | string | External PostgreSQL connection string. Is always used if set regardless of the `.bundled.enabled` field. | `""` |
| database.postgres.urlFile | string | Path to a file containing the database URL. Takes precedence over url when set. Is always used if set regardless of the `.bundled.enabled` field. | `""` |
| database.postgres.vectorEnabled | bool | Enable the pgvector migration Required to use features that depend on database vector capability. (e.g. long-term memory) Set to true when using an external PostgreSQL that has the pgvector extension installed. | `false` |
| extraObjects | list | Additional arbitrary Kubernetes manifests to deploy alongside the chart. Each list entry is rendered through `tpl`, so values may reference the release context (e.g. `{{ include "kagent.fullname" . }}`, `{{ .Release.Namespace }}`). Both map and multi-line string entries are supported. Use this to manage resources such as ExternalSecret, HTTPRoute, or NetworkPolicy within the same chart lifecycle without maintaining a separate chart.  To use, replace the empty list below with your manifests, e.g.:   extraObjects:     - apiVersion: external-secrets.io/v1       kind: ExternalSecret       metadata:         name: '{{ include "kagent.fullname" . }}-openai'         namespace: '{{ .Release.Namespace }}'       spec:         secretStoreRef:           name: aws-secretsmanager           kind: ClusterSecretStore         target:           name: kagent-openai         data:           - secretKey: OPENAI_API_KEY             remoteRef:               key: prod/kagent/openai               property: api_key | [] |
| fullnameOverride | string | Override the full name of the chart | `"kagent"` |
| global.licensing.createSecret | bool | When true the chart creates a singleton Secret from licenseKey. kmcp-enterprise will reference the same Secret rather than creating its own. | `true` |
| global.licensing.licenseFilePath | string | Absolute path to the license key file inside a mounted volume (e.g. CSI / Google Secret Manager). | `nil` |
| global.licensing.licenseKey | string | Contact Sales if you do not have an Enterprise kagent license key. | `nil` |
| global.licensing.secretName | string | Name of the singleton Secret shared across all enterprise subcharts. | `"enterprise-kagent-license"` |
| grafana-mcp.enabled | bool | Enable Grafana MCP server for Grafana integration | `false` |
| grafana-mcp.fullnameOverride | string |  | `"kagent-grafana-mcp"` |
| grafana-mcp.grafana.apiKey | string | Grafana API key. Deprecated - use serviceAccountToken instead. | `"-"` |
| grafana-mcp.grafana.serviceAccountToken | string | Grafana service account token (preferred over apiKey) | `""` |
| grafana-mcp.grafana.url | string | Grafana API URL | `"grafana.kagent:3000/api"` |
| grafana-mcp.resources | object | Resource requests and limits for grafana-mcp | `{"limits":{"cpu":"500m","memory":"512Mi"},"requests":{"cpu":"100m","memory":"128Mi"}}` |
| helm-agent.enabled | bool | Enable Helm agent for managing Helm releases | `false` |
| helm-agent.memory.enabled | bool |  | `false` |
| helm-agent.memory.modelConfigRef | string |  | `""` |
| helm-agent.memory.ttlDays | int |  | `15` |
| helm-agent.modelConfigRef | string |  | `""` |
| helm-agent.resources | object | Resource requests and limits for helm-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| imagePullPolicy | string | Image pull policy for all components | `"IfNotPresent"` |
| imagePullSecrets | list | Image pull secrets for private registries | `[]` |
| ipv6 | object | Enable IPv6/dual-stack support. When true, configures all components for dual-stack (IPv4+IPv6) networking:   - nginx listens on both IPv4 and IPv6 (adds `listen [::]:8080`)   - Next.js binds to `::` instead of `0.0.0.0`   - Agent pods bind to `::` for dual-stack reachability Leave disabled on clusters where IPv6 is disabled at the kernel level. | false |
| istio-agent.enabled | bool | Enable Istio service mesh agent | `false` |
| istio-agent.memory.enabled | bool |  | `false` |
| istio-agent.memory.modelConfigRef | string |  | `""` |
| istio-agent.memory.ttlDays | int |  | `15` |
| istio-agent.modelConfigRef | string |  | `""` |
| istio-agent.resources | object | Resource requests and limits for istio-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| k8s-agent.enabled | bool | Enable Kubernetes agent for managing K8s resources | `false` |
| k8s-agent.memory.enabled | bool |  | `false` |
| k8s-agent.memory.modelConfigRef | string |  | `""` |
| k8s-agent.memory.ttlDays | int |  | `15` |
| k8s-agent.modelConfigRef | string |  | `""` |
| k8s-agent.resources | object | Resource requests and limits for k8s-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| kagent-tools.enabled | bool | Enable kagent-tools deployment | `false` |
| kagent-tools.fullnameOverride | string | Override the full name for kagent-tools | `"kagent-tools"` |
| kagent-tools.podSecurityContext.runAsNonRoot | bool |  | `true` |
| kagent-tools.podSecurityContext.seccompProfile.type | string |  | `"RuntimeDefault"` |
| kagent-tools.replicaCount | int | Number of kagent-tools replicas | `1` |
| kagent-tools.resources | object | Resource requests and limits for kagent-tools | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| kagent-tools.securityContext.allowPrivilegeEscalation | bool |  | `false` |
| kagent-tools.securityContext.capabilities.drop[0] | string |  | `"ALL"` |
| kagent-tools.tools.env | list | Additional environment variables for the kagent-tools container. The default keeps every tool-call trace even when a service mesh or an upstream service marks the incoming request as not sampled, matching the default of `otel.tracing.sampler`. Overriding this list replaces it, so re-add the sampler entry alongside your own variables unless you want kagent-tools to inherit the caller's sampling decision. | `[{"name":"OTEL_TRACES_SAMPLER","value":"always_on"}]` |
| kagent-tools.tools.k8s.tokenPassthrough | bool | Require token from auth header for kubectl (when true). Default false: use in-cluster SA token. | `false` |
| kagent-tools.tools.loglevel | string | Log level for kagent-tools | `"debug"` |
| kagent-tools.tools.metrics.port | int |  | `8085` |
| kagent-tools.useDefaultServiceAccount | bool | Use default service account (no RBAC). Set to true to use default SA; false creates a dedicated SA and ClusterRole/ClusterRoleBinding | `false` |
| kgateway-agent.enabled | bool | Enable Kubernetes Gateway API agent | `false` |
| kgateway-agent.memory.enabled | bool |  | `false` |
| kgateway-agent.memory.modelConfigRef | string |  | `""` |
| kgateway-agent.memory.ttlDays | int |  | `15` |
| kgateway-agent.modelConfigRef | string |  | `""` |
| kgateway-agent.resources | object | Resource requests and limits for kgateway-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| kmcp.controller.kagentControllerServiceAccount | string | ServiceAccount of the kagent controller, allowed on the MCPServer waypoint AuthorizationPolicy so the controller can reach MCP servers under ambient. Must match the kagent controller SA ("<fullname>-controller"); update if fullnameOverride is changed from the default. | `"kagent-controller"` |
| kmcp.enabled | bool | Enable kmcp deployment | `true` |
| kmcp.image | object | Image configuration (only override enterprise-specific values) | `{"name":"kmcp-enterprise-controller","pullPolicy":"","registry":"us-docker.pkg.dev/solo-public","repository":"kagent-enterprise","tag":""}` |
| kmcp.image.name | string | Image name | `"kmcp-enterprise-controller"` |
| kmcp.image.pullPolicy | string | Image pull policy | `""` |
| kmcp.image.registry | string | Container registry | `"us-docker.pkg.dev/solo-public"` |
| kmcp.image.repository | string | Image repository | `"kagent-enterprise"` |
| kmcp.image.tag | string | Tag for the image If unset, defaults to the global tag, then to the chart version. | `""` |
| kmcp.resources | object | Resource limits and requests (override upstream defaults for enterprise) | `{"limits":{"cpu":"500m","memory":"512Mi"},"requests":{"cpu":"100m","memory":"128Mi"}}` |
| kubernetes.jwksUrl | string | Override the JWKS discovery URL for Kubernetes service account token validation (optional). When not set, JWKS is discovered using the well-known OIDC endpoint on the cluster's api server | `""` |
| labels | object | Additional labels to add to all Kubernetes resources | `{}` |
| licensing.createSecret | string | Per-chart override for createSecret. Null means use global.licensing.createSecret. Set to true/false only when you need this chart to behave differently from the global default. | `nil` |
| licensing.licenseFilePath | string | Per-chart override for licenseFilePath. Null means use global.licensing.licenseFilePath. Sets ENTERPRISE_KAGENT_LICENSE_KEY_PATH; the controller reads the license key from this file at startup. You must also configure the volume source and mount via controller.volumes and controller.volumeMounts so the file actually exists at this path inside the container. When set, takes precedence over secretName. Example: /etc/kagent/enterprise-kagent-license-key | `nil` |
| licensing.licenseKey | string | Per-chart override for licenseKey. Null means use global.licensing.licenseKey. | `nil` |
| licensing.secretName | string | Per-chart override for secretName. Null means use global.licensing.secretName. | `nil` |
| nameOverride | string | Override the name of the chart | `""` |
| namespaceOverride | string | Override the namespace | `.Release.Namespace` |
| nodeSelector | object | Node labels to match for `Pod` [scheduling](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/). | `{}` |
| oauth2-proxy.config.clientID | string |  | `""` |
| oauth2-proxy.config.clientSecret | string |  | `""` |
| oauth2-proxy.config.cookieSecret | string |  | `""` |
| oauth2-proxy.config.existingSecret | string |  | `""` |
| oauth2-proxy.enabled | bool |  | `false` |
| oauth2-proxy.extraArgs.approval-prompt | string |  | `"auto"` |
| oauth2-proxy.extraArgs.cookie-samesite | string |  | `"lax"` |
| oauth2-proxy.extraArgs.cookie-secure | bool |  | `true` |
| oauth2-proxy.extraArgs.custom-templates-dir | string |  | `"/templates"` |
| oauth2-proxy.extraArgs.email-domain | string |  | `"*"` |
| oauth2-proxy.extraArgs.oidc-issuer-url | string |  | `"$(OIDC_ISSUER_URL)"` |
| oauth2-proxy.extraArgs.pass-authorization-header | bool |  | `true` |
| oauth2-proxy.extraArgs.provider | string |  | `"oidc"` |
| oauth2-proxy.extraArgs.redirect-url | string |  | `"$(OIDC_REDIRECT_URL)"` |
| oauth2-proxy.extraArgs.scope | string |  | `"openid profile email groups"` |
| oauth2-proxy.extraArgs.set-authorization-header | bool |  | `true` |
| oauth2-proxy.extraArgs.skip-auth-regex | string |  | `"^/(login|_next/static|_next/image|login-bg\\.(jpg|png|webp)|logo-.*\\.png|favicon\\.ico|api/agentharnesses/.*/gateway).*$"` |
| oauth2-proxy.extraArgs.skip-auth-route | string |  | `"^/(health|login)$"` |
| oauth2-proxy.extraArgs.skip-jwt-bearer-tokens | bool |  | `true` |
| oauth2-proxy.extraArgs.upstream | string |  | `"$(UPSTREAM_URL)"` |
| oauth2-proxy.extraEnv[0].name | string |  | `"OIDC_ISSUER_URL"` |
| oauth2-proxy.extraEnv[0].value | string |  | `""` |
| oauth2-proxy.extraEnv[1].name | string |  | `"OIDC_REDIRECT_URL"` |
| oauth2-proxy.extraEnv[1].value | string |  | `""` |
| oauth2-proxy.extraEnv[2].name | string |  | `"UPSTREAM_URL"` |
| oauth2-proxy.extraEnv[2].value | string |  | `"http://kagent-ui:8080"` |
| oauth2-proxy.extraVolumeMounts[0].mountPath | string |  | `"/templates"` |
| oauth2-proxy.extraVolumeMounts[0].name | string |  | `"custom-templates"` |
| oauth2-proxy.extraVolumeMounts[0].readOnly | bool |  | `true` |
| oauth2-proxy.extraVolumes[0].configMap.name | string |  | `"kagent-oauth2-proxy-templates"` |
| oauth2-proxy.extraVolumes[0].name | string |  | `"custom-templates"` |
| oauth2-proxy.redis.enabled | bool |  | `false` |
| oauth2-proxy.service.portNumber | int |  | `4180` |
| oauth2-proxy.service.type | string |  | `"ClusterIP"` |
| oauth2-proxy.sessionStorage.type | string |  | `"cookie"` |
| observability-agent.enabled | bool | Enable observability agent for metrics and monitoring | `false` |
| observability-agent.memory.enabled | bool |  | `false` |
| observability-agent.memory.modelConfigRef | string |  | `""` |
| observability-agent.memory.ttlDays | int |  | `15` |
| observability-agent.modelConfigRef | string |  | `""` |
| observability-agent.resources | object | Resource requests and limits for observability-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| oidc.autoAuthBaseURL | string | Management autoauth base URL used when issuer is empty. Set this when the management chart uses nameOverride/fullnameOverride or a different namespace. | `""` |
| oidc.clientId | string | OIDC client identifier | `"kagent-enterprise"` |
| oidc.issuer | string | OIDC identity provider issuer URL | `""` |
| oidc.oboClaimsToPropagate | list | @deprecated Use agentgateway-enterprise's STS server for token exchange instead. Configure AllowedSubjectClaims on the agentgateway-enterprise STS configuration. This field will be removed in a future release. | `[]` |
| oidc.secret | string | OIDC client secret (if secretRef is not used) | `""` |
| oidc.secretKey | string | OIDC secret key that the secret is associated with | `"clientSecret"` |
| oidc.secretRef | string | Reference to existing secret containing OIDC client secret | `"kagent-enterprise-oidc-secret"` |
| oidc.skipOBO | bool | @deprecated Use agentgateway-enterprise's STS server for token exchange instead. When using agentgateway-enterprise, configure the agent's STS_WELL_KNOWN_URI environment variable to point to the STS server. This field will be removed in a future release. | `false` |
| oidc.stsWellKnownUri | string | URI to the STS well-known endpoint for token exchange. When set, agents will use this STS for OBO token exchange via the STS_WELL_KNOWN_URI environment variable injected into each agent pod. Example: "http://agentgateway-enterprise-controller.kagent-system:7777/.well-known/openid-configuration" | `""` |
| otel.logging.enabled | bool | Enable OpenTelemetry logging | `false` |
| otel.logging.exporter.otlp.endpoint | string |  | `""` |
| otel.logging.exporter.otlp.insecure | bool |  | `true` |
| otel.logging.exporter.otlp.timeout | int |  | `15000` |
| otel.tracing.enabled | bool | Enable OpenTelemetry tracing | `false` |
| otel.tracing.exporter.otlp.endpoint | string |  | `""` |
| otel.tracing.exporter.otlp.insecure | bool |  | `true` |
| otel.tracing.exporter.otlp.protocol | string |  | `"grpc"` |
| otel.tracing.exporter.otlp.timeout | int |  | `15000` |
| otel.tracing.sampler | string | Trace sampler for the kagent controller and the agent pods it creates. The default `always_on` keeps every kagent trace even when a service mesh or an upstream service marks the incoming request as not sampled. Set to `parentbased_always_on` to inherit the caller's sampling decision instead, or to any other sampler from the OpenTelemetry specification. An empty value leaves the SDK default in place. | `"always_on"` |
| otel.tracing.samplerArg | string | Argument for samplers that take one, such as `traceidratio`. | `""` |
| podAnnotations | object | Additional annotations to add to all pods | `{}` |
| podLabels | object | Additional labels to add to all pod templates (merged into pod labels of the controller and UI Deployments; can be overridden per component). Useful for admission policies that require specific labels on pods. | `{}` |
| podSecurityContext | object | Security context for all pods | `{"runAsNonRoot":true,"seccompProfile":{"type":"RuntimeDefault"}}` |
| promql-agent.enabled | bool | Enable PromQL agent for Prometheus queries | `false` |
| promql-agent.memory.enabled | bool |  | `false` |
| promql-agent.memory.modelConfigRef | string |  | `""` |
| promql-agent.memory.ttlDays | int |  | `15` |
| promql-agent.modelConfigRef | string |  | `""` |
| promql-agent.resources | object | Resource requests and limits for promql-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| providers.annotations | object | Annotations added to the metadata of the generated default ModelConfig (the one derived from `providers.default`). Omitted from the resource when empty. | `{}` |
| providers.anthropic.apiKeySecretKey | string | Key in secret containing the API key | `"ANTHROPIC_API_KEY"` |
| providers.anthropic.apiKeySecretRef | string | Name of secret containing Anthropic API key | `"kagent-anthropic"` |
| providers.anthropic.model | string | Anthropic model to use | `"claude-haiku-4-5"` |
| providers.anthropic.provider | string | Provider name | `"Anthropic"` |
| providers.azureOpenAI.apiKeySecretKey | string | Key in secret containing the API key | `"AZUREOPENAI_API_KEY"` |
| providers.azureOpenAI.apiKeySecretRef | string | Name of secret containing Azure OpenAI API key | `"kagent-azure-openai"` |
| providers.azureOpenAI.config | object | Azure OpenAI configuration | `{"apiVersion":"2023-05-15","azureAdToken":"","azureDeployment":"","azureEndpoint":""}` |
| providers.azureOpenAI.config.apiVersion | string | Azure OpenAI API version | `"2023-05-15"` |
| providers.azureOpenAI.config.azureAdToken | string | Azure AD token for authentication | `""` |
| providers.azureOpenAI.config.azureDeployment | string | Azure OpenAI deployment name | `""` |
| providers.azureOpenAI.config.azureEndpoint | string | Azure OpenAI endpoint URL | `""` |
| providers.azureOpenAI.model | string | Azure OpenAI model to use | `"gpt-4.1-mini"` |
| providers.azureOpenAI.provider | string | Provider name | `"AzureOpenAI"` |
| providers.bedrock.apiKeySecretKey | string | Key in secret containing the AWS access key ID | `"AWS_ACCESS_KEY_ID"` |
| providers.bedrock.apiKeySecretRef | string | Name of secret containing AWS credentials (access key ID and secret access key) | `"kagent-bedrock"` |
| providers.bedrock.config | object | AWS Bedrock configuration | `{"region":"us-east-1"}` |
| providers.bedrock.config.region | string | AWS region where the Bedrock model is available (e.g., us-east-1, us-west-2) | `"us-east-1"` |
| providers.bedrock.model | string | AWS Bedrock model to use (e.g., anthropic.claude-3-5-sonnet-20241022-v2:0) | `"anthropic.claude-3-5-sonnet-20241022-v2:0"` |
| providers.bedrock.provider | string | Provider name | `"Bedrock"` |
| providers.default | string | Default LLM provider to use. Update if you use another provider. | `"openAI"` |
| providers.gemini.apiKeySecretKey | string | Key in secret containing the API key | `"GOOGLE_API_KEY"` |
| providers.gemini.apiKeySecretRef | string | Name of secret containing Gemini API key | `"kagent-gemini"` |
| providers.gemini.model | string | Gemini model to use | `"gemini-2.0-flash-lite"` |
| providers.gemini.provider | string | Provider name | `"Gemini"` |
| providers.ollama.config | object | Ollama configuration | `{"host":"host.docker.internal:11434","options":{"num_ctx":"64000"}}` |
| providers.ollama.config.host | string | Ollama host URL | `"host.docker.internal:11434"` |
| providers.ollama.model | string | Ollama model to use | `"llama3.2"` |
| providers.ollama.provider | string | Provider name | `"Ollama"` |
| providers.openAI.apiKeySecretKey | string | Key in secret containing the OpenAI API key | `"OPENAI_API_KEY"` |
| providers.openAI.apiKeySecretRef | string | Name of secret containing OpenAI API key | `"kagent-openai"` |
| providers.openAI.model | string | OpenAI model to use | `"gpt-4.1-mini"` |
| providers.openAI.provider | string | Provider name | `"OpenAI"` |
| proxy | object | Proxy configuration for decarative agents | `{"url":""}` |
| proxy.url | string | Proxy URL for decarative agents (e.g. "http://proxy.kagent.svc.cluster.local:8080") | `""` |
| proxy.url | string |  | `""` |
| rbac.namespaces | list | Namespaces in which to create Role and RoleBinding resources. If empty (default), the chart creates cluster-scoped ClusterRole and ClusterRoleBinding resources and the controller watches all namespaces. If set, the chart creates a Role + RoleBinding per listed namespace and the controller's WATCH_NAMESPACES is derived from this list (unless controller.watchNamespaces is set explicitly, which always takes precedence). | `[]` |
| rbac.roleMapping | object | Role mapping configuration (only created when oidc.issuer is set) | `{"roleMapper":"claims.Groups.transformList(i, v, v in rolesMap, rolesMap[v])","roleMappings":{"admins":"global.Admin","readers":"global.Reader","writers":"global.Writer"}}` |
| rbac.roleMapping.roleMapper | string | CEL expression to map OIDC claims to roles. Variables: 'claims', 'rolesMap' | `"claims.Groups.transformList(i, v, v in rolesMap, rolesMap[v])"` |
| rbac.roleMapping.roleMappings | object | Map of IdP groups to internal roles (global.Admin, global.Writer, global.Reader) | `{"admins":"global.Admin","readers":"global.Reader","writers":"global.Writer"}` |
| registry | string | Container registry for kagent images | `"ghcr.io"` |
| securityContext | object | Security context for all containers | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true}` |
| substrate.enabled | bool |  | `false` |
| substrateWorkerPool | object | Optional Agent Substrate WorkerPool installed by this chart. This is platform capacity and is not owned by individual AgentHarness resources. | `{"ateomImage":"","create":false,"labels":{},"name":"kagent-default","replicas":1,"sandboxClass":"gvisor","template":{}}` |
| tag | string | Default image tag (used when component tag is unset). Empty uses Chart version. | `""` |
| tolerations | list | Node taints to be tolerated for `Pod` [scheduling](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/). | `[]` |
| ui.additionalForwardedHeaders | list | Additional request headers (beyond Authorization) the UI proxy will forward to the backend. Names are case-insensitive. Hop-by-hop headers (Connection, Transfer-Encoding, etc.) are silently dropped. | `[]` |
| ui.affinity | object | [Affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#affinity-and-anti-affinity) rules for the UI pod. | `{}` |
| ui.annotations | object | Additional annotations to add to the UI Deployment metadata | `{}` |
| ui.auth.ssoRedirectPath | string |  | `"/oauth2/start"` |
| ui.backendInternalUrl | string | Next.js server default when set (BACKEND_INTERNAL_URL). Override if the controller API base differs. | `""` |
| ui.enabled | bool |  | `false` |
| ui.env | object | Additional configuration key-value pairs for the UI ConfigMap | `{}` |
| ui.externalUrl | string | Public-facing base URL of the UI (e.g. https://kagent.example.com). When set, the controller injects KAGENT_UI_URL into agent pods so that share link tools return full clickable URLs instead of relative paths. | "" (share tools return paths only) |
| ui.httpRoute | object | Gateway API `HTTPRoute` for the UI. Requires the Gateway API CRDs (`gateway.networking.k8s.io/v1`) and an existing `Gateway` to attach to via `parentRefs`. Disabled by default; enable to front the UI with a Gateway API implementation (kgateway, Istio, Envoy Gateway, etc.) instead of the OpenShift Route or bundled oauth2-proxy. | `{"annotations":{},"enabled":false,"hostnames":[],"labels":{},"parentRefs":[],"rules":[]}` |
| ui.httpRoute.annotations | object | Annotations to add to the `HTTPRoute`. | `{}` |
| ui.httpRoute.hostnames | list | Hostnames matched by the route. | `[]` |
| ui.httpRoute.labels | object | Extra labels to add to the `HTTPRoute` (merged with the chart labels). | `{}` |
| ui.httpRoute.parentRefs | list | Gateways this route attaches to. Required when `enabled` is `true`. | `[]` |
| ui.httpRoute.rules | list | Routing rules. When a rule omits `backendRefs`, it defaults to the UI `Service` on `ui.service.ports.port`. Each rule may also set `matches`, `filters`, and `timeouts`. | `[]` |
| ui.image.name | string | Image name for the UI image | `"ui"` |
| ui.image.pullPolicy | string | Image pull policy for UI | `""` |
| ui.image.registry | string | Container registry for UI image | `"cr.kagent.dev"` |
| ui.image.repository | string | Repository for UI image | `"kagent-dev/kagent"` |
| ui.image.tag | string | Tag for UI image. | `"0.10.0-rc5"` |
| ui.nginx | object | Nginx proxy timeout configuration for the UI sidecar (values are passed directly to the corresponding nginx directives, e.g. "1800s"). | `{"proxyReadTimeout":"1800s","proxySendTimeout":"1800s"}` |
| ui.nginx.proxyReadTimeout | string | proxy_read_timeout: max time between two successive reads from the upstream. | `"1800s"` |
| ui.nginx.proxySendTimeout | string | proxy_send_timeout: max time between two successive writes to the upstream. | `"1800s"` |
| ui.nodeSelector | object | Node labels to match for `Pod` [scheduling](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/). | `{}` |
| ui.openshiftRoute.annotations."haproxy.router.openshift.io/timeout" | string |  | `"120m"` |
| ui.pdb | object | [PodDisruptionBudget](https://kubernetes.io/docs/tasks/run-application/configure-pdb/) for the UI pods. Disabled by default: `ui.replicas` is 1, and a `minAvailable: 1` budget on a single-replica Deployment blocks every voluntary eviction, so node drains and cluster upgrades hang indefinitely. Raise `ui.replicas` before switching to `minAvailable`. | `{"annotations":{},"enabled":false,"labels":{},"maxUnavailable":1,"minAvailable":null,"unhealthyPodEvictionPolicy":""}` |
| ui.pdb.annotations | object | Annotations for the UI PodDisruptionBudget. | `{}` |
| ui.pdb.enabled | bool | Set to true to create the PodDisruptionBudget. | `false` |
| ui.pdb.labels | object | Additional labels for the UI PodDisruptionBudget. | `{}` |
| ui.pdb.maxUnavailable | int | Maximum number of pods that may be unavailable. Int or percentage string (e.g. `1` or `"50%"`). Mutually exclusive with `minAvailable`. | `1` |
| ui.pdb.minAvailable | string | Minimum number of pods that must remain available. Int or percentage string (e.g. `1` or `"50%"`). Mutually exclusive with `maxUnavailable`. | unset (`maxUnavailable` is used instead) |
| ui.pdb.unhealthyPodEvictionPolicy | string | `spec.unhealthyPodEvictionPolicy`, one of `IfHealthyBudget` (the Kubernetes default) or `AlwaysAllow`. `AlwaysAllow` lets unhealthy pods be evicted even when the budget is exhausted, which avoids drains wedging on a crash-looping pod. Requires Kubernetes >= 1.27. Omitted from the manifest when empty. | "" (defer to the Kubernetes default) |
| ui.podAnnotations | object |  | `{}` |
| ui.podLabels | object | Additional labels for the UI pod template, merged over the global `podLabels` (per-key; component keys win). Selector labels can never be overridden. | `{}` |
| ui.podSecurityContext | object | Pod-level security context for the UI pod. Overrides the global podSecurityContext. | (uses global podSecurityContext) |
| ui.publicBackendUrl | string | Browser uses this path on the UI hostname (nginx proxies /api → controller). Required for client-side /api and WebSockets from outside the cluster. | `"/api"` |
| ui.readinessProbe | object | Custom readiness probe for the UI container. Override to adjust thresholds, use exec-based probes, or change the health path. | httpGet /health on port http, periodSeconds=30 |
| ui.replicas | int | Number of UI replicas | `1` |
| ui.resources | object | Resource requests and limits for UI | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| ui.route | object | Gates the OpenShift `Route` for the UI. Additionally conditional on the `route.openshift.io/v1` API being present, so it is a no-op off-OpenShift. Set to `false` to front the UI with your own Route/ingress or the bundled oauth2-proxy instead of the chart's edge-terminated Route. | `{"enabled":true}` |
| ui.securityContext | object | Container-level security context for the UI container. Overrides the global securityContext. | (uses global securityContext) |
| ui.service.annotations | object | Annotations to add to the UI Service. | `{}` |
| ui.service.ports.port | int | Service port for UI | `8080` |
| ui.service.ports.targetPort | int | Target port for UI | `8080` |
| ui.service.type | string | Service type for UI | `"ClusterIP"` |
| ui.serviceAccount | object | ServiceAccount settings for the UI pod | `{"annotations":{}}` |
| ui.serviceAccount.annotations | object | Annotations to add to the UI ServiceAccount. Useful for GCP Workload Identity, AWS IRSA, or Azure Workload Identity. | {} (no extra annotations) |
| ui.startupProbe | object | Custom startup probe for the UI container. Override to adjust thresholds, use exec-based probes, or change the health path. | httpGet /health on port http, periodSeconds=1, initialDelaySeconds=1 |
| ui.streamTimeoutSeconds | int | Client-side chat stream inactivity timeout (seconds). The browser aborts a streaming response if no event is received within this window. Should be >= ui.nginx.proxyReadTimeout so nginx isn't the silent limit. Default 1800 (30m). | `1800` |
| ui.tolerations | list | Node taints which will be tolerated for `Pod` [scheduling](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/). | `[]` |
| ui.topologySpreadConstraints | list | [Topology spread constraints](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#pod-topology-spread-constraints) for the UI pod. | `[]` |
| ui.volumes | object | EmptyDir volume sizes for Next.js UI workload (typically used when enabling readOnlyRootFilesystem) | `{"nextjsCache":"100Mi","tmp":"50Mi"}` |
| ui.volumes.nextjsCache | string | Size limit for Next.js build cache (.next/cache). Default 100Mi is sufficient for typical Next.js apps with moderate caching needs. | `"100Mi"` |
| ui.volumes.tmp | string | Size limit for temporary files (/tmp). Default 50Mi provides ample space for Next.js runtime temporary data. | `"50Mi"` |
