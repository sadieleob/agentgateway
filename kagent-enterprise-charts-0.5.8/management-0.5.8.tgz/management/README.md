<img src="https://img.shields.io/badge/Version-0.0.0-informational?style=flat-square" alt="Version: 0.0.0" align="left">

<br>Review Helm values for the Solo Enterprise for kagent `management` Helm chart.

## Overview

The management chart deploys the core Solo Enterprise for kagent components including:
- UI frontend
- UI backend gRPC/REST API server
- Tunnel server for secure communication with workload clusters
- OpenTelemetry gateway for telemetry aggregation
- ClickHouse database for data storage

For more information, see the [installation guide](https://docs.solo.io/kagent/latest/install/install-kagent/).

### OIDC configuration

{{< callout type="info" >}}
The fields that configure OIDC details default to values for the [demo installation of Keycloak](https://docs.solo.io/kagent/latest/security/idp/keycloak/), which you can deploy as part of the getting started guide. To use any IdP other than this local demo instance, you **must** change these values to your own details. For more information, see [Identity providers](https://docs.solo.io/kagent/latest/security/idp/).
{{< /callout >}}

### ClickHouse performance configuration

The following default values are set to optimize performance for systems with <16GB RAM. For more information, see the [ClickHouse documentation](https://clickhouse.com/docs/operations/tips).

```yaml
clickhouse:
  customConfig:
    mark_cache_size: 524288000  # 500MB
    concurrent_threads_soft_limit_num: 1
  profiles:
    default:
      "@replace": "1"
      max_block_size: 8192
      max_download_threads: 1
      input_format_parallel_parsing: 0
      output_format_parallel_formatting: 0
```

## Running Tests

To run the tests for this chart, run the following command:

```bash
make run-helm-unit-tests
```

This will run the tests for this chart and output the results to the console.

## Values

| Key | Type | Description | Default |
| --- | ---- | ----------- | ------- |
| affinity | object | Affinity for the UI deployment pods | `{}` |
| agentevals.database.postgres.autoMigrate | bool |  | `true` |
| agentevals.database.postgres.connectTimeoutSeconds | int |  | `600` |
| agentevals.database.postgres.schema | string |  | `"agentevals"` |
| agentevals.database.postgres.urlFile | string |  | `"/usr/share/management/postgres/url"` |
| agentevals.enabled | bool | EXPERIMENTAL. Enable the agentevals service. Off by default while the integration is in development; expect breaking changes to values keys, Secret shapes, and resource names.  Disable / re-enable contract: flipping this to false uninstalls the agentevals Deployment but leaves the `agentevals` ClickHouse database and Postgres schema in place. Re-enabling re-attaches to that data; drop it out of band first for a clean re-enable.  Acceptable for experimental: an auto-drop hook is irreversible and not worth the blast radius for an opt-in feature. Cleanup tooling is on the v1 GA list. | `false` |
| agentevals.enterprise | object | Enterprise-only knobs (not consumed by the upstream subchart). The subchart ignores unknown keys, so this sub-namespace is safe. | `{"clickhouse":{"database":"agentevals","generateConfig":true,"secretRef":"agentevals-clickhouse-config"}}` |
| agentevals.enterprise.clickhouse | object | ClickHouse configuration for the agentevals ResultSink. Targets a dedicated `agentevals` database in the shared CH instance. address/port/username/password are inherited from ui.backend.clickhouse so the chart has one source of truth per CH instance; add username/password here later if you want a service-scoped CH user for agentevals. | `{"database":"agentevals","generateConfig":true,"secretRef":"agentevals-clickhouse-config"}` |
| agentevals.enterprise.clickhouse.database | string | ClickHouse database for the agentevals ResultSink. Separate from ui.backend.clickhouse.database so result rows do not collide with platformdb tables. | `"agentevals"` |
| agentevals.enterprise.clickhouse.generateConfig | bool | Trigger generation of the secret containing clickhouse configuration | `true` |
| agentevals.enterprise.clickhouse.secretRef | string | Secret reference for the agentevals clickhouse config secret | `"agentevals-clickhouse-config"` |
| agentevals.env[0].name | string |  | `"AGENTEVALS_CLICKHOUSE_CONFIG_PATH"` |
| agentevals.env[0].value | string |  | `"/usr/share/agentevals/clickhouse-config/config.json"` |
| agentevals.env[1].name | string |  | `"INSECURE_MODE"` |
| agentevals.env[1].value | string |  | `"true"` |
| agentevals.env[2].name | string |  | `"AGENTEVALS_HEADLESS"` |
| agentevals.env[2].value | string |  | `"1"` |
| agentevals.extraVolumeMounts[0].mountPath | string |  | `"/usr/share/agentevals/clickhouse-config"` |
| agentevals.extraVolumeMounts[0].name | string |  | `"agentevals-clickhouse-config"` |
| agentevals.extraVolumeMounts[0].readOnly | bool |  | `true` |
| agentevals.extraVolumeMounts[1].mountPath | string |  | `"/usr/share/management/postgres"` |
| agentevals.extraVolumeMounts[1].name | string |  | `"management-postgres-dsn"` |
| agentevals.extraVolumeMounts[1].readOnly | bool |  | `true` |
| agentevals.extraVolumes[0].name | string |  | `"agentevals-clickhouse-config"` |
| agentevals.extraVolumes[0].secret.secretName | string |  | `"agentevals-clickhouse-config"` |
| agentevals.extraVolumes[1].name | string |  | `"management-postgres-dsn"` |
| agentevals.extraVolumes[1].secret.secretName | string |  | `"management-postgres-dsn"` |
| agentevals.fullnameOverride | string |  | `"solo-enterprise-agentevals"` |
| agentevals.image.pullPolicy | string |  | `""` |
| agentevals.image.registry | string | Container image registry. The agentevals subchart concatenates image.registry + image.repository + image.tag (it does NOT read .Values.global.image.*), so set these explicitly to point at the enterprise overlay image that carries the agentevals_kagent ClickHouse ResultSink wheel. | `""` |
| agentevals.image.repository | string | Container image repository (org/name). Override to use upstream ghcr.io/agentevals-dev/agentevals when the sink ships via plugin discovery. | `"solo-enterprise-agentevals-kagent"` |
| agentevals.image.tag | string | Image tag. Required when agentevals.enabled=true and validated at install time; an empty value would otherwise resolve to the *upstream* subchart appVersion, which is not the enterprise overlay tag. Release pipelines should pass this explicitly to match the management chart version. | `""` |
| agentevals.imagePullSecrets | list | imagePullSecrets for the agentevals subchart pod. Subchart-local; the parent chart's global.imagePullSecrets does not flow through. | `[]` |
| agentevals.podLabels."istio.io/dataplane-mode" | string |  | `"ambient"` |
| agentevals.podSecurityContext.fsGroup | int |  | `1000` |
| agentevals.rbac.create | bool |  | `true` |
| agentevals.resources.limits.cpu | string |  | `"1000m"` |
| agentevals.resources.limits.memory | string |  | `"2048Mi"` |
| agentevals.resources.requests.cpu | string |  | `"250m"` |
| agentevals.resources.requests.memory | string |  | `"512Mi"` |
| agentevals.securityContext.allowPrivilegeEscalation | bool |  | `false` |
| agentevals.securityContext.capabilities.drop[0] | string |  | `"ALL"` |
| agentevals.securityContext.readOnlyRootFilesystem | bool |  | `true` |
| agentevals.securityContext.runAsGroup | int |  | `1000` |
| agentevals.securityContext.runAsNonRoot | bool |  | `true` |
| agentevals.securityContext.runAsUser | int |  | `1000` |
| agentevals.serviceAccount.create | bool |  | `true` |
| agentevals.serviceAccount.name | string |  | `"solo-enterprise-agentevals"` |
| agentevals.storage.backend | string |  | `"postgres"` |
| clickhouse.auth.enabled | bool | Enable ClickHouse authentication | `true` |
| clickhouse.auth.password | string | ClickHouse password | `"password"` |
| clickhouse.auth.skipUserSetup | bool |  | `false` |
| clickhouse.auth.username | string | ClickHouse username | `"default"` |
| clickhouse.containerSecurityContext | object | Container-level security context for ClickHouse containers (passed through to the ClickHouse subchart). Subchart defaults: readOnlyRootFilesystem: true, allowPrivilegeEscalation: false, capabilities.drop: [ALL] | `{}` |
| clickhouse.customConfig | object | Custom ClickHouse server configuration | `{"mark_cache_size":524288000,"part_log":{"ttl":"event_date + INTERVAL 7 DAY"},"query_log":{"ttl":"event_date + INTERVAL 7 DAY"},"trace_log":{"ttl":"event_date + INTERVAL 3 DAY"}}` |
| clickhouse.database | object | database to create | `{"name":"platformdb"}` |
| clickhouse.enabled | bool | Enable ClickHouse deployment | `true` |
| clickhouse.external.address | string | External ClickHouse host (no scheme or port). | `""` |
| clickhouse.external.enabled | bool | Use an external ClickHouse endpoint instead of the bundled instance. Set clickhouse.enabled=false. | `false` |
| clickhouse.external.httpPort | int | HTTP interface port used by agentevals (clickhouse-connect). ClickHouse Cloud serves it on 8443 with TLS. | `8443` |
| clickhouse.external.migrateAddress | string | Optional host:port of a designated replica for migrations and schema version reads. Set this when clickhouse.external.address load-balances across replicas, so a lagging replica cannot hand a fresh migration Lease holder a stale schema version. | `""` |
| clickhouse.external.port | int | Native protocol port used by ui-backend, dbctl, and the collector exporters. ClickHouse Cloud serves it on 9440 with TLS. | `9440` |
| clickhouse.external.replicaAddresses | list | Per-replica host:port list for replicated schema bootstrap. A Replicated database exists only on servers that ran the CREATE. Leave this empty for operator-managed clusters that sync databases across replicas (the ClickHouse Kubernetes operator's enableDatabaseSync, on by default); bootstrap then uses clickhouse.external.address alone. List every replica when database sync is disabled or the cluster is managed by hand. | `[]` |
| clickhouse.external.replicated | bool | The external endpoint is a replicated ClickHouse cluster. Migrations then create databases with the Replicated engine and rewrite MergeTree-family table engines to their Replicated counterparts, so one migration set serves standalone and replicated servers. Leave false for ClickHouse Cloud, which replicates automatically. | `false` |
| clickhouse.external.tls.ca | string | Optional PEM CA bundle for a private CA, rendered into the generated config Secrets as ca.crt. Leave empty for publicly trusted certificates. Certificate verification is never disabled. | `""` |
| clickhouse.external.tls.enabled | bool | Connect with TLS. Required by ClickHouse Cloud. | `true` |
| clickhouse.image | object | ClickHouse image configuration | `{"repository":"clickhouse/clickhouse-server","tag":"26.3.17-alpine"}` |
| clickhouse.image.repository | string | ClickHouse image repository | `"clickhouse/clickhouse-server"` |
| clickhouse.image.tag | string | ClickHouse image tag. | `"26.3.17-alpine"` |
| clickhouse.keeper.enabled | bool | Disable ClickHouse Keeper / ZooKeeper | `false` |
| clickhouse.livenessProbe | object | Liveness probe for ClickHouse | `{"failureThreshold":3,"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"tcpSocket":{"port":"http"},"timeoutSeconds":5}` |
| clickhouse.livenessProbe.failureThreshold | int | Failure threshold for liveness probe | `3` |
| clickhouse.livenessProbe.initialDelaySeconds | int | Initial delay seconds for liveness probe | `10` |
| clickhouse.livenessProbe.periodSeconds | int | Period seconds for liveness probe | `10` |
| clickhouse.livenessProbe.successThreshold | int | Success threshold for liveness probe | `1` |
| clickhouse.livenessProbe.timeoutSeconds | int | Timeout seconds for liveness probe | `5` |
| clickhouse.metrics | object | Enable ClickHouse Prometheus metrics endpoint | `{"enabled":true,"port":9363}` |
| clickhouse.metrics.port | int | Port number for the ClickHouse Prometheus metrics endpoint | `9363` |
| clickhouse.persistentVolume.emptyDirSizeLimit | string | Cap the data emptyDir below the ephemeral-storage limit above. Traces and chat spans are retained indefinitely, so the data directory has no natural ceiling. Exceeding this evicts the pod and destroys the emptyDir; enable persistentVolume for history you intend to keep, or cap retention with `dbctl retention set --days N`. | `"15Gi"` |
| clickhouse.persistentVolume.enabled | bool | Persistent storage for the bundled ClickHouse data. Off by default: the bundled instance ships for evaluation and small installs, and production setups should bring their own ClickHouse (clickhouse.external or a BYO endpoint). Enabling this on an existing ephemeral install requires a one-time step because volumeClaimTemplates are immutable on a live StatefulSet; the render-time guard names the procedure. | `false` |
| clickhouse.persistentVolume.size | string | Size of the ClickHouse data volume. | `"20Gi"` |
| clickhouse.persistentVolume.storageClass | string | Storage class for the ClickHouse data volume (default class if empty). | `""` |
| clickhouse.profiles | object | User performance profiles | `{"default":{"@replace":"1","max_execution_time":60}}` |
| clickhouse.readinessProbe | object | Readiness probe for ClickHouse | `{"failureThreshold":3,"httpGet":{"path":"/ping","port":"http"},"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| clickhouse.readinessProbe.failureThreshold | int | Failure threshold for readiness probe | `3` |
| clickhouse.readinessProbe.initialDelaySeconds | int | Initial delay seconds for readiness probe | `10` |
| clickhouse.readinessProbe.periodSeconds | int | Period seconds for readiness probe | `10` |
| clickhouse.readinessProbe.successThreshold | int | Success threshold for readiness probe | `1` |
| clickhouse.readinessProbe.timeoutSeconds | int | Timeout seconds for readiness probe | `5` |
| clickhouse.replicasPerShard | int | Number of ClickHouse replicas | `1` |
| clickhouse.resources | object | Resource preset for ClickHouse | `{"limits":{"cpu":6,"ephemeral-storage":"20Gi","memory":"12288Mi"},"requests":{"cpu":2,"ephemeral-storage":"50Mi","memory":"3072Mi"}}` |
| clickhouse.securityContext | object | Pod-level security context for ClickHouse pods (passed through to the ClickHouse subchart). Subchart defaults: runAsUser/runAsGroup/fsGroup: 101, runAsNonRoot: true, fsGroupChangePolicy: OnRootMismatch. On OpenShift, null runAsUser/runAsGroup/fsGroup so the restricted SCC assigns a project-scoped UID. | `{}` |
| clickhouse.shards | int | Number of ClickHouse shards | `1` |
| cluster | string | Name of the cluster where this chart is deployed - must only contain letters, digits, hyphens (-) and dots (.), start and end with a letter or digit, and be between 1 and 253 characters | `"mgmt-cluster"` |
| database | object | Postgres connection used by services in this chart. Must point at the same database the kagent-enterprise chart uses; agentevals owns its own schema inside that database. | `{"postgres":{"url":"","urlFile":""}}` |
| database.postgres.url | string | External PostgreSQL connection string. Required when agentevals.enabled is true unless urlFile is set. | `""` |
| database.postgres.urlFile | string | Path to a file containing the database URL. Takes precedence over url when set. | `""` |
| fullnameOverride | string |  | `""` |
| global.image.registry | string | Fallback registry for all solo-owned images. Excludes third party images. Per-image registry takes precedence when set. | `"us-docker.pkg.dev/solo-public"` |
| global.image.repository | string | Fallback repository for all solo-owned images. Excludes third party images. Per-image repository takes precedence when set. | `"solo-enterprise"` |
| global.image.tag | string | Fallback tag for all solo-owned images. Excludes third party images. Per-image tag takes precedence when set; falls back to chart version if both are unset. | `""` |
| global.imagePullPolicy | string | Configure image pull policy for all images in this chart | `"IfNotPresent"` |
| global.imagePullSecrets | list | Image pull secrets for private registries. Propagated to all subcharts. | `[]` |
| idp.name | string | Image name for the IDP | `"solo-enterprise-autoauth"` |
| idp.pullPolicy | string | Image pull policy for the IDP image | `""` |
| idp.registry | string | Registry for the IDP image. | `"us-docker.pkg.dev/solo-public"` |
| idp.repository | string | Repository for the IDP image. | `"solo-enterprise"` |
| idp.securityContext | object | Container security context for idp | (uses global securityContext) |
| idp.tag | string | Image tag for the IDP image | `"v0.2.3"` |
| imagePullSecrets | list | Image pull secrets for private registries. @deprecated Use global.imagePullSecrets instead. This field will be removed in a future release. | `[]` |
| istio | object | Istio ambient mode integration. When enabled (the default), in-mesh pods are labeled with `istio.io/dataplane-mode=ambient` and cross-cluster Services with `solo.io/service-scope=global`, so ambient multi-cluster routing works without any post-install labeling. Disable when installing into a cluster that is not running ambient mode. | `{"ambient":{"enabled":true}}` |
| istio.ambient.enabled | bool | Apply ambient dataplane-mode and global service-scope labels automatically on install. | `true` |
| kubernetes.watchNamespaces | list | List of namespaces to watch for Kubernetes resources | `[]` |
| licensing.createSecret | bool | When true the chart creates a Secret from licenseKey. Requires secretName and licenseKey. If you use your own Secret, changing it only takes effect after a pod restart. | `true` |
| licensing.licenseFilePath | string | Absolute path to the license key file inside a mounted volume (e.g. CSI / Google Secret Manager). Sets LICENSE_KEY_PATH; the ui-backend reads the license key from this file at startup. You must also configure the volume source and mount via ui.backend.volumes and ui.backend.volumeMounts so the file actually exists at this path inside the container. When set, takes precedence over secretName and suppresses Secret creation (createSecret is ignored). Example: /etc/solo-enterprise/license-key | `nil` |
| licensing.licenseKey | string | Contact Sales if you do not have an Enterprise license key | `nil` |
| licensing.secretName | string | Name of the Secret containing the Solo Enterprise license key. Leave empty to default to "license-keys" (or "<nameOverride>-license-keys" when a naming override is set); set to BYO an existing license Secret. | `""` |
| management-crds | object | When enabled CRDs are installed automatically | `{"enabled":true}` |
| nameOverride | string | Override the base name used for namespaced resources, labels, and in-cluster DNS references. Defaults preserve the chart's historical resource names. RBAC names always include the Helm release name and installation namespace, so installs in different namespaces do not collide. For multiple installs in the same namespace, set a distinct nameOverride or fullnameOverride on each. | `""` |
| nodeSelector | object | Node selector for the UI deployment pods | `{}` |
| oidc.additionalScopes | list | Additional client scopes to be requested during authentication | `[]` |
| oidc.issuer | string | OIDC identity provider issuer URL This is used to discover OIDC endpoints (authorization, token, logout, etc.) via the well-known discovery endpoint: {issuer}/.well-known/openid-configuration | `""` |
| platform.multiCluster.enabled | bool |  | `true` |
| podSecurityContext | object | Pod-level security context for the UI deployment (applies to all containers in the UI pod) | `{"runAsNonRoot":true}` |
| products.agentgateway | object | Agentgateway Enterprise integration configuration | `{"enabled":false,"features":{"cost-management":false,"cost-management-writes":true},"namespace":""}` |
| products.agentgateway.enabled | bool | Enable the agentgateway product integration | `false` |
| products.agentgateway.features | object | Opt-in feature toggles for the agentgateway product UI | `{"cost-management":false,"cost-management-writes":true}` |
| products.agentgateway.features.cost-management | bool | Show the Cost Management UI. Off by default so performance-sensitive clusters do not incur the feature's unoptimized ClickHouse reads until opted in. | `false` |
| products.agentgateway.features.cost-management-writes | bool | Allow the Cost Management UI/backend to write budgets, dimensions, and virtual API keys. Disable to expose read-only cost views. | `true` |
| products.agentgateway.namespace | string | Optional, default is installation namespace. If namespace is other than installation, set this to the namespace where agentgateway controller is installed. | `""` |
| products.kagent | object | Kagent Enterprise integration configuration | `{"enabled":false,"namespace":""}` |
| products.kagent.enabled | bool | Enable the kagent product integration | `false` |
| products.kagent.namespace | string | Optional, default is installation namespace. If namespace is other than installation, set this to the namespace where kagent controller is installed. In multi-cluster installations, all instances of kagent controller must be in the same namespace. | `""` |
| products.mesh | object | Service Mesh Enterprise integration configuration | `{"enabled":false,"features":{"agent-interfaces":false}}` |
| products.mesh.enabled | bool | Enable the service mesh product integration | `false` |
| products.mesh.features | object | Opt-in feature toggles for the mesh product | `{"agent-interfaces":false}` |
| products.mesh.features.agent-interfaces | bool | Master switch for the AI-agent interfaces to the mesh UI (design/mesh/agent-interfaces.md): the Mesh MCP endpoint and its user sign-in, the composite diagnostic RPCs, saved views with the Share button and /ie/view short links, and findings with their UI. Off by default so an upgrade changes nothing until an install opts in. | `false` |
| rbac.roleMapping.defaultRoles | list | Roles granted to every authenticated user in addition to the mapped roles. Must be a list of role-name strings or null. When unset (null), defaults to ["global.Authenticated"] if products.mesh.enabled is true, and [] otherwise. The global.Authenticated role lets any logged-in user read the mesh UI APIs (Fleet Graph, Global Services, Dashboard), list connected clusters, and fetch their own user info, regardless of their claims; the backend ignores it when the mesh product is disabled. Set explicitly to override the automatic default; [] requires a mapped role for all access. | `nil` |
| rbac.roleMapping.roleMapper | string | CEL expression to map OIDC claims to roles. Variables: 'claims', 'rolesMap' | `"has(claims.Groups) ? claims.Groups.transformList(i, v, v in rolesMap, rolesMap[v]) : []"` |
| rbac.roleMapping.roleMappings | object | Map of IdP groups to internal roles (global.Admin, global.Writer, global.Reader) | `{"admins":"global.Admin","readers":"global.Reader","writers":"global.Writer"}` |
| securityContext | object | Default container-level security context applied to all containers (can be overridden per-container) | `{"readOnlyRootFilesystem":true}` |
| service.annotations | object | Annotations shared by the externally exposed Services (solo-enterprise-ui, solo-enterprise-telemetry-gateway, and in multi-cluster mode solo-enterprise-tunnel), for example AWS load balancer controller annotations. An annotation that names one load balancer or address belongs in the per-Service maps below instead, since a non-empty per-Service annotations map replaces this one for that Service. | `{}` |
| service.clusterIP | string | Cluster IP to assign to the service | `""` |
| service.telemetryGateway.annotations | object | Annotations for solo-enterprise-telemetry-gateway. Replaces service.annotations when non-empty. | `{}` |
| service.telemetryGateway.type | string | Service type for solo-enterprise-telemetry-gateway. Defaults to service.type. | `""` |
| service.tunnel.annotations | object | Annotations for solo-enterprise-tunnel. Replaces service.annotations when non-empty. | `{}` |
| service.tunnel.type | string | Service type for solo-enterprise-tunnel. Defaults to service.type. | `""` |
| service.type | string | Type of service to create | `"LoadBalancer"` |
| service.ui.annotations | object | Annotations for solo-enterprise-ui. Replaces service.annotations when non-empty. | `{}` |
| service.ui.type | string | Service type for solo-enterprise-ui. Defaults to service.type. | `""` |
| telemetry.clickhouse | object | ClickHouse credentials for the OTel collectors (telemetry + k8sobjects). OTel reads connection details from the named Secret via ${file:/etc/clickhouse-config/<key>} substitution (flat-key format only — address, port, database, username, password; legacy config.json is not supported on the writer side). | `{"generateConfig":true,"secretRef":""}` |
| telemetry.clickhouse.generateConfig | bool | Generate the chart-managed Secret. When this OR ui.backend.clickhouse.generateConfig is true, the chart renders a single Secret named "solo-enterprise-clickhouse-config" (or "<nameOverride>-clickhouse-config" when a naming override is set) from ui.backend.clickhouse values. Set to false and override secretRef to BYO a writer Secret (useful for reader/writer credential split). | `true` |
| telemetry.clickhouse.secretRef | string | Secret the OTel collectors read ClickHouse credentials from. Leave empty to default to the chart-managed Secret; set to point at a BYO writer Secret. | `""` |
| telemetry.collector.affinity | object | Affinity for the telemetry collector pods | `{}` |
| telemetry.collector.livenessProbe | object | Liveness probe configuration | `{"failureThreshold":3,"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| telemetry.collector.nodeSelector | object | Node selector for the telemetry collector pods | `{}` |
| telemetry.collector.persistentQueue.enabled | bool | Buffer exporter queues on a persistent volume and retry until delivery. Enabling this on an existing install that collects metrics requires a one-time StatefulSet recreation (delete it with cascade=orphan, then upgrade) because volumeClaimTemplates are immutable; the upgrade fails early with the exact commands. | `false` |
| telemetry.collector.persistentQueue.fsGroup | int | fsGroup added to the pod security context while a queue volume is mounted, so the collector (uid/gid 10001) can write a provisioned volume that arrives root-owned. Set to null on OpenShift, where the restricted SCC assigns a project-scoped GID instead. | `10001` |
| telemetry.collector.persistentQueue.queueSizeBytes | int | Logical byte cap for the queues of one collector pod, divided equally across its queue files, one per exporter per signal (three, or four when traces are collected). The chart also caps those files on disk at an equal share of 85% of size, so this must stay at or below that; the gap covers storage overhead. Raise both together to ride out longer outages. | `8000000000` |
| telemetry.collector.persistentQueue.size | string | Size of each queue volume. Whole or decimal number with a k, M, G, T, Ki, Mi, Gi, or Ti suffix. | `"10Gi"` |
| telemetry.collector.persistentQueue.storageClass | string | StorageClass for the queue volumes. Empty uses the cluster default. | `""` |
| telemetry.collector.podSecurityContext | object | Pod-level security context for the telemetry collector workload. When persistentQueue is enabled the chart adds fsGroup (persistentQueue.fsGroup) unless this sets one, because the collector image runs as uid/gid 10001 and provisioned volumes arrive root-owned. | `{}` |
| telemetry.collector.readinessProbe | object | Readiness probe configuration | `{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| telemetry.collector.replicaCount | int | Number of replicas. When telemetry.metrics.enabled=true and products.mesh.enabled=true, a single replica scrapes all Prometheus targets cluster-wide. Increase replicaCount and enable sharding to distribute scrape load across multiple replicas. | `1` |
| telemetry.collector.resources | object | Resources for the telemetry collector | `{"limits":{"cpu":"1000m","memory":"2Gi"},"requests":{"cpu":"200m","memory":"512Mi"}}` |
| telemetry.collector.securityContext | object | Container security context for telemetry collector | (uses global securityContext) |
| telemetry.collector.sharding | object | Sharding configuration for distributing Prometheus scrape targets across replicas. Sharding uses hashmod relabeling to ensure each target is scraped by exactly one collector. Requires metric collection (metrics.enabled=true and products.mesh.enabled=true) and replicaCount > 1. | `{"enabled":false}` |
| telemetry.collector.sharding.enabled | bool | Enable sharding of collector targets | `false` |
| telemetry.collector.tolerations | list | Tolerations for the telemetry collector pods | `[]` |
| telemetry.image | object | Shared image configuration for all telemetry collectors | `{"name":"opentelemetry-collector-contrib","pullPolicy":"","registry":"docker.io","repository":"otel","tag":"0.158.0"}` |
| telemetry.image.name | string | Image name | `"opentelemetry-collector-contrib"` |
| telemetry.image.pullPolicy | string | Image pull policy | `""` |
| telemetry.image.registry | string | Image registry | `"docker.io"` |
| telemetry.image.repository | string | Image repository | `"otel"` |
| telemetry.image.tag | string | OpenTelemetry collector image tag | `"0.158.0"` |
| telemetry.k8sobjects.affinity | object | Affinity for the k8sobjects collector pods. Empty (default) inherits the top-level affinity. | `{}` |
| telemetry.k8sobjects.enabled | bool | Enable the k8sobjects collector | `true` |
| telemetry.k8sobjects.livenessProbe | object | Liveness probe configuration | `{"failureThreshold":3,"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| telemetry.k8sobjects.nodeSelector | object | Node selector for the k8sobjects collector pods. Empty (default) inherits the top-level nodeSelector, which placed the collector before it had its own Deployment. | `{}` |
| telemetry.k8sobjects.persistentQueue.enabled | bool | Enable the persistent send queue. Backed by a ReadWriteOnce PVC, which forces the collector Deployment to schedule where the volume attaches. | `false` |
| telemetry.k8sobjects.persistentQueue.fsGroup | int | fsGroup added to the pod security context while the queue volume is mounted, so the collector (uid/gid 10001) can write a provisioned volume that arrives root-owned. Set to null on OpenShift, where the restricted SCC assigns a project-scoped GID instead. | `10001` |
| telemetry.k8sobjects.persistentQueue.queueSizeBytes | int | Logical byte cap for the queue. The chart also caps the queue file on disk at 85% of size, so this must stay at or below that; the gap covers storage overhead. Raise both together to ride out longer outages. | `8000000000` |
| telemetry.k8sobjects.persistentQueue.size | string | Size of the queue volume. Whole or decimal number with a k, M, G, T, Ki, Mi, Gi, or Ti suffix. | `"10Gi"` |
| telemetry.k8sobjects.persistentQueue.storageClass | string | Storage class for the queue volume (default class if empty). | `""` |
| telemetry.k8sobjects.podSecurityContext | object | Pod-level security context for the k8sobjects collector pods. Empty (default) inherits the top-level podSecurityContext, which applied to the collector before it had its own Deployment. When persistentQueue is enabled the chart adds fsGroup (persistentQueue.fsGroup) unless the effective context sets one, because the collector image runs as uid/gid 10001 and provisioned volumes arrive root-owned. | (uses global podSecurityContext) |
| telemetry.k8sobjects.readinessProbe | object | Readiness probe configuration | `{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| telemetry.k8sobjects.replicaCount | int | Number of k8sobjects collector replicas. Values greater than 1 enable leader election (k8s_leader_elector extension) so exactly one replica collects at a time and the others stand by. A newly elected leader re-lists the watched objects, which is idempotent for the current-state tables. Incompatible with persistentQueue, whose volume allows one writer. | `1` |
| telemetry.k8sobjects.resources | object | Resources for the k8sobjects collector | `{"limits":{"cpu":"300m","memory":"768Mi"},"requests":{"cpu":"100m","memory":"384Mi"}}` |
| telemetry.k8sobjects.securityContext | object | Container security context for k8sobjects collector | (uses global securityContext) |
| telemetry.k8sobjects.tolerations | list | Tolerations for the k8sobjects collector pods. Empty (default) inherits the top-level tolerations. | `[]` |
| telemetry.metrics.enabled | bool | Enable Prometheus metrics scraping. Only the Service Mesh Enterprise product collects metrics, so this is ignored unless `products.mesh.enabled` is true. | `true` |
| telemetry.selfMonitoring.enabled | bool | Enable platform self-monitoring metrics collection into ClickHouse | `false` |
| telemetry.selfMonitoring.verbose | bool | Enable verbose self-monitoring (disables metric filtering). When true, all scraped metrics are stored (not recommended for production). | `false` |
| telemetry.traces.enabled | bool | Enable OTLP trace ingestion. Only the kagent Enterprise and agentgateway Enterprise products collect traces, so this is ignored unless `products.kagent.enabled` or `products.agentgateway.enabled` is true. | `true` |
| tolerations | list | Tolerations for the UI deployment pods | `[]` |
| traces.verbose | bool | Enable verbose traces (disables strict filtering) | `false` |
| tunnelserver.affinity | object | Affinity for the tunnel server pods. Empty (default) inherits the top-level affinity. | `{}` |
| tunnelserver.authSecretRef | string | Existing Secret holding the internal tunnel auth token under the `token` key. Empty (default) lets the chart generate and manage the Secret, rolling the tunnel and UI Deployments when the token changes. Set this in template-only pipelines (ArgoCD), where the chart-managed token regenerates on every sync; rotating a referenced Secret requires restarting both Deployments, since the token is read once at startup. | `""` |
| tunnelserver.drainGracePeriodSeconds | int | How long a terminating tunnel server pod waits for in-flight tunnel requests to finish before closing its held tunnels. The pod's terminationGracePeriodSeconds is derived from this plus 15s of headroom. | `25` |
| tunnelserver.livenessProbe | object | Liveness probe for tunnel server | `{"failureThreshold":3,"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| tunnelserver.livenessProbe.failureThreshold | int | Failure threshold for liveness probe | `3` |
| tunnelserver.livenessProbe.initialDelaySeconds | int | Initial delay seconds for liveness probe | `10` |
| tunnelserver.livenessProbe.periodSeconds | int | Period seconds for liveness probe | `10` |
| tunnelserver.livenessProbe.successThreshold | int | Success threshold for liveness probe | `1` |
| tunnelserver.livenessProbe.timeoutSeconds | int | Timeout seconds for liveness probe | `5` |
| tunnelserver.name | string | Image name for tunnel server | `"solo-enterprise-tunnel-server"` |
| tunnelserver.nodeSelector | object | Node selector for the tunnel server pods. Empty (default) inherits the top-level nodeSelector, which placed the tunnel server before it had its own Deployment. | `{}` |
| tunnelserver.podSecurityContext | object | Pod-level security context for the tunnel server pods | (uses global podSecurityContext) |
| tunnelserver.pullPolicy | string | Image pull policy for the tunnel server image | `""` |
| tunnelserver.readinessProbe | object | Readiness probe for tunnel server | `{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| tunnelserver.readinessProbe.failureThreshold | int | Failure threshold for readiness probe | `3` |
| tunnelserver.readinessProbe.initialDelaySeconds | int | Initial delay seconds for readiness probe | `5` |
| tunnelserver.readinessProbe.periodSeconds | int | Period seconds for readiness probe | `10` |
| tunnelserver.readinessProbe.successThreshold | int | Success threshold for readiness probe | `1` |
| tunnelserver.readinessProbe.timeoutSeconds | int | Timeout seconds for readiness probe | `5` |
| tunnelserver.registry | string | Registry for the tunnel server image. Overrides global.registry when set. | `""` |
| tunnelserver.replicaCount | int | Number of tunnel server replicas. Values greater than 1 require multi-cluster mode. The tunnel server runs in its own Deployment (solo-enterprise-tunnel); after upgrading from releases where it ran inside the UI pod, repoint relay installs (tunnel.fqdn) at the solo-enterprise-tunnel Service. | `1` |
| tunnelserver.repository | string | Repository for the tunnel server image. Overrides global.repository when set. | `""` |
| tunnelserver.resources | object | Resources for tunnel server. If this is set by the user, it will override all defaults from values.yaml | `{"limits":{"cpu":"500m","memory":"1024Mi"},"requests":{"cpu":"250m","memory":"512Mi"}}` |
| tunnelserver.resources.limits | object | Resources for tunnel server. If this is set by the user, it will override all defaults from values.yaml. If this is set to null, it will not render the limits block. | `{"cpu":"500m","memory":"1024Mi"}` |
| tunnelserver.resources.limits.cpu | string | CPU limits for tunnel server | `"500m"` |
| tunnelserver.resources.limits.memory | string | Memory limits for tunnel server | `"1024Mi"` |
| tunnelserver.resources.requests | object | Resources for tunnel server. If this is set by the user, it will override all defaults from values.yaml. If this is set to null, it will not render the requests block. | `{"cpu":"250m","memory":"512Mi"}` |
| tunnelserver.resources.requests.cpu | string | CPU requests for tunnel server | `"250m"` |
| tunnelserver.resources.requests.memory | string | Memory requests for tunnel server | `"512Mi"` |
| tunnelserver.securityContext | object | Container security context for tunnel server | (uses global securityContext) |
| tunnelserver.tag | string | Tag for the tunnel server image. Overrides global.tag when set; falls back to chart version if both are unset. | `""` |
| tunnelserver.tolerations | list | Tolerations for the tunnel server pods. Empty (default) inherits the top-level tolerations. | `[]` |
| tunnelserver.topologySpreadConstraints | list | Topology spread constraints for the tunnel server pods. Empty (default) spreads replicas across hostname and zone with ScheduleAnyway. | `[]` |
| ui.backend.agentLimits | object | Per-user request budgets for AI agents acting through the Mesh MCP endpoint with a person's own sign-in. The budget is keyed by the user, so one person's agents share it; a person's own browser session is exempt. All optional; leave unset to use the in-code defaults. Set a value to 0 to disable that control. | `{"expensiveRequestsPerMinute":"","maxInFlight":"","requestsPerMinute":""}` |
| ui.backend.agentLimits.expensiveRequestsPerMinute | string | Requests per minute for expensive methods (workload- and node-level GetGraph, GetObjectDefinition, the Resources list RPCs, and the WhatsChanged, FindAnomalies, and BlastRadius composites); these also charge the sustained budget. Default 12. | `""` |
| ui.backend.agentLimits.maxInFlight | string | Max concurrent in-flight requests per user's agents (streams count for their lifetime). Default 4. | `""` |
| ui.backend.agentLimits.requestsPerMinute | string | Sustained requests per minute per user's agents, as a token bucket with a one-minute burst. Default 60. | `""` |
| ui.backend.clickhouse | object | Clickhouse configuration for the UI backend | `{"address":"","database":"platformdb","generateConfig":true,"maxIdleConns":16,"maxOpenConns":32,"password":"password","port":9000,"secretRef":"","username":"default"}` |
| ui.backend.clickhouse.address | string | clickhouse server address | `""` |
| ui.backend.clickhouse.database | string | clickhouse database to connect to | `"platformdb"` |
| ui.backend.clickhouse.generateConfig | bool | Generate the chart-managed flat-key Secret consumed by ui-backend. When this OR telemetry.clickhouse.generateConfig is true, the chart renders a single Secret named "solo-enterprise-clickhouse-config" (or "<nameOverride>-clickhouse-config" when a naming override is set) from the values below (plus tls and ca.crt keys when clickhouse.external is enabled). Set to false and override secretRef to BYO; BYO Secrets may carry the same optional tls and ca.crt keys. ui-backend additionally accepts a legacy `config.json` key for backwards compat with the pre-flat-key format (deprecated; see chart README for migration). | `true` |
| ui.backend.clickhouse.maxIdleConns | int | maximum number of idle connections in the ui-backend clickhouse pool | `16` |
| ui.backend.clickhouse.maxOpenConns | int | maximum number of open connections in the ui-backend clickhouse pool | `32` |
| ui.backend.clickhouse.password | string | password to use to connect to clickhouse server | `"password"` |
| ui.backend.clickhouse.port | int | clickhouse server port | `9000` |
| ui.backend.clickhouse.secretRef | string | Secret ui-backend reads ClickHouse credentials from. Leave empty to default to the chart-managed Secret; set to point at a BYO Secret. | `""` |
| ui.backend.clickhouse.username | string | username to use to connect to clickhouse server | `"default"` |
| ui.backend.database | object | Database startup behavior for ui-backend | `{"skipMigrations":false}` |
| ui.backend.database.skipMigrations | bool | Verify-only startup: fail fast when the ClickHouse schema is behind or dirty instead of applying migrations in-pod. Run migrations out-of-band with the solo-enterprise-migrations image when enabled. | `false` |
| ui.backend.eastWestGateway | object | Additional detection rules for self-managed east-west gateways whose Deployments do not carry the istio.io-eastwest-controller managed label. The built-in prefixes ("istio-eastwest", "istio-remote-peer-") are always applied; values below extend detection for custom naming. | `{"namePrefixes":[],"names":[]}` |
| ui.backend.eastWestGateway.namePrefixes | list | Deployment-name prefixes that mark a workload as an east-west gateway. | `[]` |
| ui.backend.eastWestGateway.names | list | Exact Deployment names that mark a workload as an east-west gateway. | `[]` |
| ui.backend.extraEnvs | object | Extra environment variables for the backend container | `{}` |
| ui.backend.fleetGraph | object | Fleet Graph DAO query bounds for a memory-limited ClickHouse. All optional; leave unset to use the in-code defaults. Raise these on larger ClickHouse instances to trade memory for speed. | `{"enrichmentConcurrency":"","enrichmentMaxMemoryBytes":"","externalGroupByBytes":"","gaugeHealthFreshnessSeconds":""}` |
| ui.backend.fleetGraph.enrichmentConcurrency | string | Max concurrent GetWorkloadEnrichment scans. Higher values cut enrichment latency but raise peak memory. Default 2. | `""` |
| ui.backend.fleetGraph.enrichmentMaxMemoryBytes | string | Per-query memory cap (bytes) on a single enrichment scan; one scan fast-fails instead of the node killing an unrelated query. Default 1073741824 (1 GiB). | `""` |
| ui.backend.fleetGraph.externalGroupByBytes | string | GROUP BY size (bytes) past which Fleet Graph queries (graph metrics and the GetFilters enrichment queries) spill aggregation to disk instead of erroring under memory pressure. Default 268435456 (256 MiB). | `""` |
| ui.backend.fleetGraph.gaugeHealthFreshnessSeconds | string | Max age (seconds) of an Istio health gauge that can still raise an "unhealthy endpoint" warning. Filters stale, latched ztunnel outlier-detection and membership values so transient dips that already recovered do not show as standing events. Default 600 (10 minutes). | `""` |
| ui.backend.kubernetesObjects | object | Resources list (ListKubernetesObjects) DAO query bounds for a memory-limited ClickHouse. Optional; leave unset to use the in-code defaults. | `{"externalAggBytes":"","listMaxMemoryBytes":""}` |
| ui.backend.kubernetesObjects.externalAggBytes | string | Size (bytes) past which the Resources list dedup GROUP BY and ORDER BY spill to disk instead of growing in memory. Default 268435456 (256 MiB). | `""` |
| ui.backend.kubernetesObjects.listMaxMemoryBytes | string | Per-query memory cap (bytes) for the Resources list query. Default 1073741824 (1 GiB). | `""` |
| ui.backend.livenessProbe | object | Liveness probe for the backend | `{"failureThreshold":3,"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| ui.backend.livenessProbe.failureThreshold | int | Failure threshold for liveness probe | `3` |
| ui.backend.livenessProbe.initialDelaySeconds | int | Initial delay seconds for liveness probe | `10` |
| ui.backend.livenessProbe.periodSeconds | int | Period seconds for liveness probe | `10` |
| ui.backend.livenessProbe.successThreshold | int | Success threshold for liveness probe | `1` |
| ui.backend.livenessProbe.timeoutSeconds | int | Timeout seconds for liveness probe | `5` |
| ui.backend.mcp | object | Mesh MCP server: a curated AI-agent tool catalog over the mesh read APIs, served at /api/mcp (design/mesh/agent-interfaces.md). Serves only when products.mesh.enabled and products.mesh.features.agent-interfaces are also true. | `{"allowedOrigins":[],"enabled":true,"oauth":{"accessTokenTtlSeconds":"","enabled":true,"sessionTtlSeconds":""},"port":8092,"publicUrl":"","service":{"annotations":{},"port":80,"type":"ClusterIP"}}` |
| ui.backend.mcp.allowedOrigins | list | Extra browser origins allowed to call /api/mcp, as scheme://host[:port] strings. The publicUrl and ui.publicUrl origins are always allowed, and requests without an Origin header (non-browser clients) always pass. | `[]` |
| ui.backend.mcp.enabled | bool | Serve the Mesh MCP endpoint (streamable HTTP at /api/mcp) on installs that enable products.mesh.features.agent-interfaces. The endpoint listens on its own container port (port) and is published by its own Service (service), ClusterIP by default, so exposing it is a separate decision from exposing the UI. Every request must present a bearer token bound to the MCP audience (publicUrl + "/api/mcp", or the in-cluster fallback). Set false to opt out of the endpoint while keeping the other agent-interfaces surfaces. | `true` |
| ui.backend.mcp.oauth | object | Built-in OAuth 2.1 authorization server for the MCP endpoint, which lets an MCP client such as Claude Code act for a signed-in user: the client discovers the server through the RFC 9728 metadata, registers itself, sends the user's browser to the mesh UI to sign in and approve it, and receives tokens ui-backend accepts as that user, with the user's own roles. No identity-provider configuration is needed. The server's issuer is the MCP resource identifier (publicUrl + "/api/mcp"); the browser is sent to ui.publicUrl to sign in and approve, so set both for clients outside the cluster. Delegated sessions are budgeted per user (ui.backend.agentLimits) and audit-logged with the client name. See _docs/mesh-mcp-server.md. | `{"accessTokenTtlSeconds":"","enabled":true,"sessionTtlSeconds":""}` |
| ui.backend.mcp.oauth.accessTokenTtlSeconds | string | Access token lifetime in seconds. Empty uses the backend default (3600). A client refreshes silently within the session. | `""` |
| ui.backend.mcp.oauth.enabled | bool | Serve the authorization server under /api/mcp/oauth and advertise it in the protected-resource metadata. When false the metadata advertises the configured OIDC issuer instead, and clients need a token from it that carries the MCP audience. | `true` |
| ui.backend.mcp.oauth.sessionTtlSeconds | string | Session lifetime in seconds from the user's approval, after which the client must send the user back through sign-in. Empty uses the backend default (28800, eight hours). | `""` |
| ui.backend.mcp.port | int | Container port ui-backend serves the MCP endpoint on. | `8092` |
| ui.backend.mcp.publicUrl | string | Canonical external base URL of the MCP endpoint (scheme, host, and any base path), with no trailing slash, for example "https://mesh-mcp.example.com". The MCP resource identifier and MCP audience are publicUrl + "/api/mcp", and its origin is an allowed browser origin. When empty they fall back to the MCP Service's in-cluster URL, which is what in-fleet agents use. Set it whenever MCP clients reach the endpoint from outside the cluster; when an ingress routes the endpoint under the UI's own hostname, set it to the same value as ui.publicUrl. | `""` |
| ui.backend.mcp.service | object | The Service publishing the MCP endpoint, solo-enterprise-mesh-mcp on a default install (naming override aware), separate from solo-enterprise-ui so it can be exposed selectively. | `{"annotations":{},"port":80,"type":"ClusterIP"}` |
| ui.backend.mcp.service.annotations | object | Annotations for the Service, for example load balancer controller annotations. | `{}` |
| ui.backend.mcp.service.port | int | Service port. The in-cluster URL omits it when it is 80. | `80` |
| ui.backend.mcp.service.type | string | Service type. ClusterIP (the default) keeps the endpoint in-cluster; set LoadBalancer, or route an Ingress or Gateway to the Service, to expose it, with TLS in front. | `"ClusterIP"` |
| ui.backend.metrics | object | Prometheus metrics endpoint configuration for ui-backend | `{"port":9090}` |
| ui.backend.metrics.port | int | Port for the Prometheus metrics endpoint served by the ui-backend | `9090` |
| ui.backend.metricsBackendHost | string | URL where ui-backend reaches the tunnel server's internal metrics port for connected-cluster state (GET /clusters). ui-backend always queries this address and unions the answer with every replica found through the tunnel headless Service, so it counts even when pod IPs are not reachable from the UI pod. Despite the generic name this is not a metrics destination and must never point at an external metrics backend such as Prometheus or Datadog. Empty (default) resolves to the solo-enterprise-tunnel-internal Service in the release namespace, which is correct for every in-cluster install. A loopback address, the default before the tunnel server had its own Deployment, is refused at render time. | `""` |
| ui.backend.name | string | Image name for the backend | `"solo-enterprise-ui-backend"` |
| ui.backend.oidc | object | OIDC configuration for the UI backend | `{"clientId":"kagent-backend","secret":"","secretKey":"clientSecret","secretRef":"ui-backend-oidc-secret"}` |
| ui.backend.oidc.clientId | string | Name of the OIDC client that you created for token validation in the UI backend | `"kagent-backend"` |
| ui.backend.oidc.secret | string | OIDC client secret (if secretRef is not used) | `""` |
| ui.backend.oidc.secretKey | string | OIDC secret key that the secret is associated with | `"clientSecret"` |
| ui.backend.oidc.secretRef | string | Secret reference for the OIDC client secret | `"ui-backend-oidc-secret"` |
| ui.backend.pullPolicy | string | Image pull policy for the backend image | `""` |
| ui.backend.readinessProbe | object | Readiness probe for the backend | `{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| ui.backend.readinessProbe.failureThreshold | int | Failure threshold for readiness probe | `3` |
| ui.backend.readinessProbe.initialDelaySeconds | int | Initial delay seconds for readiness probe | `5` |
| ui.backend.readinessProbe.periodSeconds | int | Period seconds for readiness probe | `10` |
| ui.backend.readinessProbe.successThreshold | int | Success threshold for readiness probe | `1` |
| ui.backend.readinessProbe.timeoutSeconds | int | Timeout seconds for readiness probe | `5` |
| ui.backend.registry | string | Registry for the backend image. Overrides global.registry when set. | `""` |
| ui.backend.repository | string | Repository for the backend image. Overrides global.repository when set. | `""` |
| ui.backend.resources | object | Resources for the backend. If this is set by the user, it will override all defaults from values.yaml | `{"limits":{"cpu":"500m","memory":"1024Mi"},"requests":{"cpu":"250m","memory":"512Mi"}}` |
| ui.backend.resources.limits | object | Resources for the backend. If this is set by the user, it will override all defaults from values.yaml. If this is set to null, it will not render the limits block. | `{"cpu":"500m","memory":"1024Mi"}` |
| ui.backend.resources.limits.cpu | string | CPU limits for the backend | `"500m"` |
| ui.backend.resources.limits.memory | string | Memory limits for the backend | `"1024Mi"` |
| ui.backend.resources.requests | object | Resources for the backend. If this is set by the user, it will override all defaults from values.yaml. If this is set to null, it will not render the requests block. | `{"cpu":"250m","memory":"512Mi"}` |
| ui.backend.resources.requests.cpu | string | CPU requests for the backend | `"250m"` |
| ui.backend.resources.requests.memory | string | Memory requests for the backend | `"512Mi"` |
| ui.backend.securityContext | object | Container security context for ui-backend | (uses global securityContext) |
| ui.backend.startupProbe | object | Startup probe for the backend. Liveness and readiness checks wait until it passes, so with the defaults startup ClickHouse migrations get up to 30 minutes before the kubelet restarts the pod. A single migration statement is also capped at 30 minutes by the migrate client; when raising this budget past that, also set CLICKHOUSE_MIGRATE_READ_TIMEOUT (a Go duration) via extraEnvs. The deployment's progressDeadlineSeconds is derived from this budget so rollout status is not falsely reported as stalled while migrations run. | `{"enabled":true,"failureThreshold":180,"periodSeconds":10,"timeoutSeconds":5}` |
| ui.backend.startupProbe.enabled | bool | Enables the startup probe. Disabling restores the previous behavior where the liveness probe can kill the pod during long startup migrations; intended only for dev setups that prefer the fastest restart loop. | `true` |
| ui.backend.startupProbe.failureThreshold | int | Failure threshold for startup probe. Together with periodSeconds this bounds the total startup time. | `180` |
| ui.backend.startupProbe.periodSeconds | int | Period seconds for startup probe | `10` |
| ui.backend.startupProbe.timeoutSeconds | int | Timeout seconds for startup probe | `5` |
| ui.backend.tunnelPeerDiscovery | bool | Discover every tunnel server replica through the tunnel headless Service and union their connected-cluster state with the answer from metricsBackendHost. This needs the UI pod to reach the tunnel pods on port 8080. Set false where a NetworkPolicy or mesh rule allows only Service traffic; ui-backend then reads metricsBackendHost alone, which is exact at one tunnel replica, so the chart refuses false with tunnelserver.replicaCount above 1. | `true` |
| ui.backend.volumeMounts | list | Additional volumeMounts on the ui-backend container. Useful for mounting license keys from external secret stores (e.g. CSI / Google Secret Manager). Required when using licensing.licenseFilePath. | `[]` |
| ui.backend.volumes | list | Additional volumes on the Deployment. Useful for mounting license keys from external secret stores (e.g. CSI / Google Secret Manager). Required when using licensing.licenseFilePath. | `[]` |
| ui.basePath | string | Base path for the UI (e.g. "/my-app"). When non-empty, the frontend assets are served under this prefix. Must start with "/" and must not end with "/". Leave empty (default) to serve at root. | `""` |
| ui.frontend.enableMockUI | bool | Enable showing mock data on the frontend | `false` |
| ui.frontend.livenessProbe | object | Liveness probe for the frontend | `{"failureThreshold":3,"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| ui.frontend.livenessProbe.failureThreshold | int | Failure threshold for liveness probe | `3` |
| ui.frontend.livenessProbe.initialDelaySeconds | int | Initial delay seconds for liveness probe | `10` |
| ui.frontend.livenessProbe.periodSeconds | int | Period seconds for liveness probe | `10` |
| ui.frontend.livenessProbe.successThreshold | int | Success threshold for liveness probe | `1` |
| ui.frontend.livenessProbe.timeoutSeconds | int | Timeout seconds for liveness probe | `5` |
| ui.frontend.name | string | Image name for the frontend | `"solo-enterprise-ui-frontend"` |
| ui.frontend.oidc | object | OIDC configuration for the frontend | `{"clientId":"kagent-ui"}` |
| ui.frontend.oidc.clientId | string | Name of the public-access OIDC client that you created for the frontend | `"kagent-ui"` |
| ui.frontend.pullPolicy | string | Image pull policy for the frontend image | `""` |
| ui.frontend.readinessProbe | object | Readiness probe for the frontend | `{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| ui.frontend.readinessProbe.failureThreshold | int | Failure threshold for readiness probe | `3` |
| ui.frontend.readinessProbe.initialDelaySeconds | int | Initial delay seconds for readiness probe | `5` |
| ui.frontend.readinessProbe.periodSeconds | int | Period seconds for readiness probe | `10` |
| ui.frontend.readinessProbe.successThreshold | int | Success threshold for readiness probe | `1` |
| ui.frontend.readinessProbe.timeoutSeconds | int | Timeout seconds for readiness probe | `5` |
| ui.frontend.registry | string | Registry for the frontend image. Overrides global.registry when set. | `""` |
| ui.frontend.repository | string | Repository for the frontend image. Overrides global.repository when set. | `""` |
| ui.frontend.resources | object | Resources for the frontend. If this is set by the user, it will override all defaults from values.yaml | `{"limits":{"cpu":"500m","memory":"1024Mi"},"requests":{"cpu":"250m","memory":"512Mi"}}` |
| ui.frontend.resources.limits | object | Resources for the frontend. If this is set by the user, it will override all defaults from values.yaml. If this is set to null, it will not render the limits block. | `{"cpu":"500m","memory":"1024Mi"}` |
| ui.frontend.resources.limits.cpu | string | CPU limits for the frontend | `"500m"` |
| ui.frontend.resources.limits.memory | string | Memory limits for the frontend | `"1024Mi"` |
| ui.frontend.resources.requests | object | Resources for the frontend. If this is set by the user, it will override all defaults from values.yaml. If this is set to null, it will not render the requests block. | `{"cpu":"250m","memory":"512Mi"}` |
| ui.frontend.resources.requests.cpu | string | CPU requests for the frontend | `"250m"` |
| ui.frontend.resources.requests.memory | string | Memory requests for the frontend | `"512Mi"` |
| ui.frontend.securityContext | object | Container security context for ui-frontend | (uses global securityContext) |
| ui.frontend.uiBackendHost | string | Backend service URL (the frontend uses "{ui-frontend-url}" if the value here is "") | `""` |
| ui.frontend.volumes | object | EmptyDir volume sizes for the ui-frontend (required for readOnlyRootFilesystem) | `{"uiHtml":"50Mi","uiTmp":"5Mi"}` |
| ui.frontend.volumes.uiHtml | string | Size limit for the HTML content dir. dist/ is ~20Mi today (4.6Mi JS bundle + 2Mi PNGs + CSS/fonts); 50Mi gives ~2.5x headroom for growth. | `"50Mi"` |
| ui.frontend.volumes.uiTmp | string | Size limit for the temp directory. | `"5Mi"` |
| ui.publicUrl | string | Canonical external base URL of the UI (scheme, host, and any base path), with no trailing slash, for example "https://mesh.example.com". The agent interfaces use it for the root of absolute links returned to clients that have no browser origin, such as an agent putting a proving link in a chat reply, for the page the MCP sign-in flow sends a user's browser to, and as an allowed browser origin on the MCP endpoint. When empty, links are site-relative for the frontend to complete and the sign-in flow addresses the consent page by the UI's in-cluster Service URL, so user sign-in from outside the cluster needs it set. The MCP endpoint's own address is ui.backend.mcp.publicUrl. | `""` |
| ui.replicaCount | int | Number of UI replicas. Values greater than 1 require an external OIDC issuer (oidc.issuer); the built-in autoAuth IdP signs tokens with a per-pod key and stays single-replica. | `1` |
| ui.topologySpreadConstraints | list | Topology spread constraints for the UI pods. Empty (default) spreads replicas across hostname and zone with ScheduleAnyway. | `[]` |
